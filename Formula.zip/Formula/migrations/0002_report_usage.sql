-- 上报使用量计数表：限流防滥用
-- 限制：同一设备每日总共 ≤ 20 次上报，单化学式每日 ≤ 3 次上报
-- 主键 (device_id, formula, report_date) 天然去重计数

CREATE TABLE IF NOT EXISTS report_usage (
  device_id    TEXT NOT NULL,             -- 前端生成的设备 UUID
  formula      TEXT NOT NULL,             -- 规范化化学式
  report_date  TEXT NOT NULL,             -- YYYY-MM-DD（按天计数）
  count        INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (device_id, formula, report_date)
);

-- 按设备+日期索引，用于查日总量
CREATE INDEX IF NOT EXISTS idx_report_device_date ON report_usage(device_id, report_date);
