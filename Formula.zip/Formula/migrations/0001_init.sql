-- D1 缓存表：联网查询过的化学式及其分析结果，避免二次查询
-- 仅缓存「本地 DB 未命中 → 走联网(PubChem+AI)」的结果
-- 本地 DB 命中的化学式不缓存（瞬时返回，无需缓存）

CREATE TABLE IF NOT EXISTS formula_cache (
  formula       TEXT PRIMARY KEY,        -- 规范化后的输入化学式（去状态符号/电荷/水合物点号统一）
  existence     TEXT NOT NULL,           -- exists/likely/questionable/unlikely
  name_cn       TEXT,
  name_en       TEXT,
  category_cn   TEXT,
  category_en   TEXT,
  mass          REAL,
  result_json   TEXT NOT NULL,           -- 完整 AnalysisResult JSON，直接反序列化返回
  created_at    INTEGER NOT NULL,
  updated_at    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_formula_lookup ON formula_cache(formula);
