// 元素周期表数据 / Periodic table data
// valences: common oxidation states (positive ones typically); negative marked with -
// group, period, category for context

export interface ElementInfo {
  z: number; // atomic number
  symbol: string;
  name_cn: string;
  name_en: string;
  mass: number; // standard atomic weight
  valences: number[]; // common oxidation states
  group: number | null;
  period: number;
  category: string;
}

export const ELEMENTS: Record<string, ElementInfo> = {
  H:  { z: 1,  symbol: "H",  name_cn: "氢",   name_en: "Hydrogen",   mass: 1.008,   valences: [1, -1],     group: 1,  period: 1, category: "nonmetal" },
  He: { z: 2,  symbol: "He", name_cn: "氦",   name_en: "Helium",     mass: 4.0026,  valences: [0],         group: 18, period: 1, category: "noble" },
  Li: { z: 3,  symbol: "Li", name_cn: "锂",   name_en: "Lithium",    mass: 6.94,    valences: [1],         group: 1,  period: 2, category: "alkali-metal" },
  Be: { z: 4,  symbol: "Be", name_cn: "铍",   name_en: "Beryllium",  mass: 9.0122,  valences: [2],         group: 2,  period: 2, category: "alkaline-earth" },
  B:  { z: 5,  symbol: "B",  name_cn: "硼",   name_en: "Boron",      mass: 10.81,   valences: [3],         group: 13, period: 2, category: "metalloid" },
  C:  { z: 6,  symbol: "C",  name_cn: "碳",   name_en: "Carbon",     mass: 12.011,  valences: [4, 2, -4],  group: 14, period: 2, category: "nonmetal" },
  N:  { z: 7,  symbol: "N",  name_cn: "氮",   name_en: "Nitrogen",   mass: 14.007,  valences: [-3, 3, 4, 5, 2, 1], group: 15, period: 2, category: "nonmetal" },
  O:  { z: 8,  symbol: "O",  name_cn: "氧",   name_en: "Oxygen",     mass: 15.999,  valences: [-2, -1, 2], group: 16, period: 2, category: "nonmetal" },
  F:  { z: 9,  symbol: "F",  name_cn: "氟",   name_en: "Fluorine",   mass: 18.998,  valences: [-1],        group: 17, period: 2, category: "halogen" },
  Ne: { z: 10, symbol: "Ne", name_cn: "氖",   name_en: "Neon",       mass: 20.180,  valences: [0],         group: 18, period: 2, category: "noble" },
  Na: { z: 11, symbol: "Na", name_cn: "钠",   name_en: "Sodium",     mass: 22.990,  valences: [1],         group: 1,  period: 3, category: "alkali-metal" },
  Mg: { z: 12, symbol: "Mg", name_cn: "镁",   name_en: "Magnesium",  mass: 24.305,  valences: [2],         group: 2,  period: 3, category: "alkaline-earth" },
  Al: { z: 13, symbol: "Al", name_cn: "铝",   name_en: "Aluminum",   mass: 26.982,  valences: [3],         group: 13, period: 3, category: "post-transition" },
  Si: { z: 14, symbol: "Si", name_cn: "硅",   name_en: "Silicon",    mass: 28.085,  valences: [4, -4],     group: 14, period: 3, category: "metalloid" },
  P:  { z: 15, symbol: "P",  name_cn: "磷",   name_en: "Phosphorus", mass: 30.974,  valences: [5, 3, -3],  group: 15, period: 3, category: "nonmetal" },
  S:  { z: 16, symbol: "S",  name_cn: "硫",   name_en: "Sulfur",     mass: 32.06,   valences: [-2, 4, 6, 2], group: 16, period: 3, category: "nonmetal" },
  Cl: { z: 17, symbol: "Cl", name_cn: "氯",   name_en: "Chlorine",   mass: 35.45,   valences: [-1, 1, 3, 5, 7], group: 17, period: 3, category: "halogen" },
  Ar: { z: 18, symbol: "Ar", name_cn: "氩",   name_en: "Argon",      mass: 39.948,  valences: [0],         group: 18, period: 3, category: "noble" },
  K:  { z: 19, symbol: "K",  name_cn: "钾",   name_en: "Potassium",  mass: 39.098,  valences: [1],         group: 1,  period: 4, category: "alkali-metal" },
  Ca: { z: 20, symbol: "Ca", name_cn: "钙",   name_en: "Calcium",    mass: 40.078,  valences: [2],         group: 2,  period: 4, category: "alkaline-earth" },
  Sc: { z: 21, symbol: "Sc", name_cn: "钪",   name_en: "Scandium",   mass: 44.956,  valences: [3],         group: 3,  period: 4, category: "transition" },
  Ti: { z: 22, symbol: "Ti", name_cn: "钛",   name_en: "Titanium",   mass: 47.867,  valences: [4, 3, 2],   group: 4,  period: 4, category: "transition" },
  V:  { z: 23, symbol: "V",  name_cn: "钒",   name_en: "Vanadium",   mass: 50.942,  valences: [5, 4, 3, 2],group: 5,  period: 4, category: "transition" },
  Cr: { z: 24, symbol: "Cr", name_cn: "铬",   name_en: "Chromium",   mass: 51.996,  valences: [3, 6, 2],   group: 6,  period: 4, category: "transition" },
  Mn: { z: 25, symbol: "Mn", name_cn: "锰",   name_en: "Manganese",  mass: 54.938,  valences: [2, 4, 7, 6, 3], group: 7, period: 4, category: "transition" },
  Fe: { z: 26, symbol: "Fe", name_cn: "铁",   name_en: "Iron",       mass: 55.845,  valences: [2, 3, 6],   group: 8,  period: 4, category: "transition" },
  Co: { z: 27, symbol: "Co", name_cn: "钴",   name_en: "Cobalt",     mass: 58.933,  valences: [2, 3],      group: 9,  period: 4, category: "transition" },
  Ni: { z: 28, symbol: "Ni", name_cn: "镍",   name_en: "Nickel",     mass: 58.693,  valences: [2, 3],      group: 10, period: 4, category: "transition" },
  Cu: { z: 29, symbol: "Cu", name_cn: "铜",   name_en: "Copper",     mass: 63.546,  valences: [2, 1],      group: 11, period: 4, category: "transition" },
  Zn: { z: 30, symbol: "Zn", name_cn: "锌",   name_en: "Zinc",       mass: 65.38,   valences: [2],         group: 12, period: 4, category: "transition" },
  Ga: { z: 31, symbol: "Ga", name_cn: "镓",   name_en: "Gallium",    mass: 69.723,  valences: [3],         group: 13, period: 4, category: "post-transition" },
  Ge: { z: 32, symbol: "Ge", name_cn: "锗",   name_en: "Germanium",  mass: 72.630,  valences: [4, 2],      group: 14, period: 4, category: "metalloid" },
  As: { z: 33, symbol: "As", name_cn: "砷",   name_en: "Arsenic",    mass: 74.922,  valences: [3, 5, -3],  group: 15, period: 4, category: "metalloid" },
  Se: { z: 34, symbol: "Se", name_cn: "硒",   name_en: "Selenium",   mass: 78.971,  valences: [-2, 4, 6],  group: 16, period: 4, category: "nonmetal" },
  Br: { z: 35, symbol: "Br", name_cn: "溴",   name_en: "Bromine",    mass: 79.904,  valences: [-1, 1, 3, 5], group: 17, period: 4, category: "halogen" },
  Kr: { z: 36, symbol: "Kr", name_cn: "氪",   name_en: "Krypton",    mass: 83.798,  valences: [0, 2],      group: 18, period: 4, category: "noble" },
  Rb: { z: 37, symbol: "Rb", name_cn: "铷",   name_en: "Rubidium",   mass: 85.468,  valences: [1],         group: 1,  period: 5, category: "alkali-metal" },
  Sr: { z: 38, symbol: "Sr", name_cn: "锶",   name_en: "Strontium",  mass: 87.62,   valences: [2],         group: 2,  period: 5, category: "alkaline-earth" },
  Y:  { z: 39, symbol: "Y",  name_cn: "钇",   name_en: "Yttrium",    mass: 88.906,  valences: [3],         group: 3,  period: 5, category: "transition" },
  Zr: { z: 40, symbol: "Zr", name_cn: "锆",   name_en: "Zirconium",  mass: 91.224,  valences: [4],         group: 4,  period: 5, category: "transition" },
  Nb: { z: 41, symbol: "Nb", name_cn: "铌",   name_en: "Niobium",    mass: 92.906,  valences: [5, 3],      group: 5,  period: 5, category: "transition" },
  Mo: { z: 42, symbol: "Mo", name_cn: "钼",   name_en: "Molybdenum", mass: 95.95,   valences: [6, 4, 2],   group: 6,  period: 5, category: "transition" },
  Tc: { z: 43, symbol: "Tc", name_cn: "锝",   name_en: "Technetium", mass: 98,      valences: [4, 7, 6],   group: 7,  period: 5, category: "transition" },
  Ru: { z: 44, symbol: "Ru", name_cn: "钌",   name_en: "Ruthenium",  mass: 101.07,  valences: [3, 4, 2],   group: 8,  period: 5, category: "transition" },
  Rh: { z: 45, symbol: "Rh", name_cn: "铑",   name_en: "Rhodium",    mass: 102.91,  valences: [3],         group: 9,  period: 5, category: "transition" },
  Pd: { z: 46, symbol: "Pd", name_cn: "钯",   name_en: "Palladium",  mass: 106.42,  valences: [2, 4],      group: 10, period: 5, category: "transition" },
  Ag: { z: 47, symbol: "Ag", name_cn: "银",   name_en: "Silver",     mass: 107.87,  valences: [1, 2],      group: 11, period: 5, category: "transition" },
  Cd: { z: 48, symbol: "Cd", name_cn: "镉",   name_en: "Cadmium",    mass: 112.41,  valences: [2],         group: 12, period: 5, category: "transition" },
  In: { z: 49, symbol: "In", name_cn: "铟",   name_en: "Indium",     mass: 114.82,  valences: [3, 1],      group: 13, period: 5, category: "post-transition" },
  Sn: { z: 50, symbol: "Sn", name_cn: "锡",   name_en: "Tin",        mass: 118.71,  valences: [4, 2],      group: 14, period: 5, category: "post-transition" },
  Sb: { z: 51, symbol: "Sb", name_cn: "锑",   name_en: "Antimony",   mass: 121.76,  valences: [3, 5, -3],  group: 15, period: 5, category: "metalloid" },
  Te: { z: 52, symbol: "Te", name_cn: "碲",   name_en: "Tellurium",  mass: 127.60,  valences: [-2, 4, 6],  group: 16, period: 5, category: "metalloid" },
  I:  { z: 53, symbol: "I",  name_cn: "碘",   name_en: "Iodine",     mass: 126.90,  valences: [-1, 1, 3, 5, 7], group: 17, period: 5, category: "halogen" },
  Xe: { z: 54, symbol: "Xe", name_cn: "氙",   name_en: "Xenon",      mass: 131.29,  valences: [0, 2, 4, 6],group: 18, period: 5, category: "noble" },
  Cs: { z: 55, symbol: "Cs", name_cn: "铯",   name_en: "Cesium",     mass: 132.91,  valences: [1],         group: 1,  period: 6, category: "alkali-metal" },
  Ba: { z: 56, symbol: "Ba", name_cn: "钡",   name_en: "Barium",     mass: 137.33,  valences: [2],         group: 2,  period: 6, category: "alkaline-earth" },
  La: { z: 57, symbol: "La", name_cn: "镧",   name_en: "Lanthanum",  mass: 138.91,  valences: [3],         group: null, period: 6, category: "lanthanide" },
  Ce: { z: 58, symbol: "Ce", name_cn: "铈",   name_en: "Cerium",     mass: 140.12,  valences: [3, 4],      group: null, period: 6, category: "lanthanide" },
  Pr: { z: 59, symbol: "Pr", name_cn: "镨",   name_en: "Praseodymium", mass: 140.91,valences: [3],         group: null, period: 6, category: "lanthanide" },
  Nd: { z: 60, symbol: "Nd", name_cn: "钕",   name_en: "Neodymium",  mass: 144.24,  valences: [3],         group: null, period: 6, category: "lanthanide" },
  Pm: { z: 61, symbol: "Pm", name_cn: "钷",   name_en: "Promethium", mass: 145,     valences: [3],         group: null, period: 6, category: "lanthanide" },
  Sm: { z: 62, symbol: "Sm", name_cn: "钐",   name_en: "Samarium",   mass: 150.36,  valences: [3, 2],      group: null, period: 6, category: "lanthanide" },
  Eu: { z: 63, symbol: "Eu", name_cn: "铕",   name_en: "Europium",   mass: 151.96,  valences: [3, 2],      group: null, period: 6, category: "lanthanide" },
  Gd: { z: 64, symbol: "Gd", name_cn: "钆",   name_en: "Gadolinium", mass: 157.25,  valences: [3],         group: null, period: 6, category: "lanthanide" },
  Tb: { z: 65, symbol: "Tb", name_cn: "铽",   name_en: "Terbium",    mass: 158.93,  valences: [3, 4],      group: null, period: 6, category: "lanthanide" },
  Dy: { z: 66, symbol: "Dy", name_cn: "镝",   name_en: "Dysprosium", mass: 162.50,  valences: [3],         group: null, period: 6, category: "lanthanide" },
  Ho: { z: 67, symbol: "Ho", name_cn: "钬",   name_en: "Holmium",    mass: 164.93,  valences: [3],         group: null, period: 6, category: "lanthanide" },
  Er: { z: 68, symbol: "Er", name_cn: "铒",   name_en: "Erbium",     mass: 167.26,  valences: [3],         group: null, period: 6, category: "lanthanide" },
  Tm: { z: 69, symbol: "Tm", name_cn: "铥",   name_en: "Thulium",    mass: 168.93,  valences: [3],         group: null, period: 6, category: "lanthanide" },
  Yb: { z: 70, symbol: "Yb", name_cn: "镱",   name_en: "Ytterbium",  mass: 173.05,  valences: [3, 2],      group: null, period: 6, category: "lanthanide" },
  Lu: { z: 71, symbol: "Lu", name_cn: "镥",   name_en: "Lutetium",   mass: 174.97,  valences: [3],         group: null, period: 6, category: "lanthanide" },
  Hf: { z: 72, symbol: "Hf", name_cn: "铪",   name_en: "Hafnium",    mass: 178.49,  valences: [4],         group: 4,  period: 6, category: "transition" },
  Ta: { z: 73, symbol: "Ta", name_cn: "钽",   name_en: "Tantalum",   mass: 180.95,  valences: [5],         group: 5,  period: 6, category: "transition" },
  W:  { z: 74, symbol: "W",  name_cn: "钨",   name_en: "Tungsten",   mass: 183.84,  valences: [6, 4, 2],   group: 6,  period: 6, category: "transition" },
  Re: { z: 75, symbol: "Re", name_cn: "铼",   name_en: "Rhenium",    mass: 186.21,  valences: [4, 7, 6],   group: 7,  period: 6, category: "transition" },
  Os: { z: 76, symbol: "Os", name_cn: "锇",   name_en: "Osmium",     mass: 190.23,  valences: [4, 3, 2],   group: 8,  period: 6, category: "transition" },
  Ir: { z: 77, symbol: "Ir", name_cn: "铱",   name_en: "Iridium",    mass: 192.22,  valences: [3, 4],      group: 9,  period: 6, category: "transition" },
  Pt: { z: 78, symbol: "Pt", name_cn: "铂",   name_en: "Platinum",   mass: 195.08,  valences: [2, 4],      group: 10, period: 6, category: "transition" },
  Au: { z: 79, symbol: "Au", name_cn: "金",   name_en: "Gold",       mass: 196.97,  valences: [3, 1],      group: 11, period: 6, category: "transition" },
  Hg: { z: 80, symbol: "Hg", name_cn: "汞",   name_en: "Mercury",    mass: 200.59,  valences: [2, 1],      group: 12, period: 6, category: "transition" },
  Tl: { z: 81, symbol: "Tl", name_cn: "铊",   name_en: "Thallium",   mass: 204.38,  valences: [1, 3],      group: 13, period: 6, category: "post-transition" },
  Pb: { z: 82, symbol: "Pb", name_cn: "铅",   name_en: "Lead",       mass: 207.2,   valences: [2, 4],      group: 14, period: 6, category: "post-transition" },
  Bi: { z: 83, symbol: "Bi", name_cn: "铋",   name_en: "Bismuth",    mass: 208.98,  valences: [3, 5],      group: 15, period: 6, category: "post-transition" },
  Po: { z: 84, symbol: "Po", name_cn: "钋",   name_en: "Polonium",   mass: 209,     valences: [-2, 2, 4],  group: 16, period: 6, category: "post-transition" },
  At: { z: 85, symbol: "At", name_cn: "砹",   name_en: "Astatine",   mass: 210,     valences: [-1, 1, 3, 5], group: 17, period: 6, category: "halogen" },
  Rn: { z: 86, symbol: "Rn", name_cn: "氡",   name_en: "Radon",      mass: 222,     valences: [0],         group: 18, period: 6, category: "noble" },
  Fr: { z: 87, symbol: "Fr", name_cn: "钫",   name_en: "Francium",   mass: 223,     valences: [1],         group: 1,  period: 7, category: "alkali-metal" },
  Ra: { z: 88, symbol: "Ra", name_cn: "镭",   name_en: "Radium",     mass: 226,     valences: [2],         group: 2,  period: 7, category: "alkaline-earth" },
  Ac: { z: 89, symbol: "Ac", name_cn: "锕",   name_en: "Actinium",   mass: 227,     valences: [3],         group: null, period: 7, category: "actinide" },
  Th: { z: 90, symbol: "Th", name_cn: "钍",   name_en: "Thorium",    mass: 232.04,  valences: [4],         group: null, period: 7, category: "actinide" },
  Pa: { z: 91, symbol: "Pa", name_cn: "镤",   name_en: "Protactinium", mass: 231.04,valences: [5, 4],      group: null, period: 7, category: "actinide" },
  U:  { z: 92, symbol: "U",  name_cn: "铀",   name_en: "Uranium",    mass: 238.03,  valences: [6, 4, 5],   group: null, period: 7, category: "actinide" },
  Np: { z: 93, symbol: "Np", name_cn: "镎",   name_en: "Neptunium",  mass: 237,     valences: [5, 4, 6],   group: null, period: 7, category: "actinide" },
  Pu: { z: 94, symbol: "Pu", name_cn: "钚",   name_en: "Plutonium",  mass: 244,     valences: [4, 6, 3],   group: null, period: 7, category: "actinide" },
  Am: { z: 95, symbol: "Am", name_cn: "镅",   name_en: "Americium",  mass: 243,     valences: [3],         group: null, period: 7, category: "actinide" },
  Cm: { z: 96, symbol: "Cm", name_cn: "锔",   name_en: "Curium",     mass: 247,     valences: [3],         group: null, period: 7, category: "actinide" },
  Bk: { z: 97, symbol: "Bk", name_cn: "锫",   name_en: "Berkelium",  mass: 247,     valences: [3],         group: null, period: 7, category: "actinide" },
  Cf: { z: 98, symbol: "Cf", name_cn: "锎",   name_en: "Californium",mass: 251,     valences: [3],         group: null, period: 7, category: "actinide" },
};

// Build a lookup that can match symbols case-insensitively but prefers exact case.
// Element symbols are: capital letter + optional lowercase letter.
export function lookupElement(token: string): ElementInfo | null {
  if (token in ELEMENTS) return ELEMENTS[token];
  // case-insensitive fallback (only if unambiguous)
  const lower = token.toLowerCase();
  const matches = Object.values(ELEMENTS).filter((e) => e.symbol.toLowerCase() === lower);
  return matches.length === 1 ? matches[0] : null;
}

export const ALL_ELEMENT_SYMBOLS = Object.keys(ELEMENTS);
