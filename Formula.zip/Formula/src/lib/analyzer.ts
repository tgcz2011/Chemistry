// 化学式分析器 / Formula analyzer
// Combines database lookup + general analysis for unknown-but-parseable formulas.

import { ELEMENTS, type ElementInfo } from "../data/elements";
import { findCompound, type Compound, type CompoundColor } from "../data/compounds";
import { parseFormula, type ParseResult } from "./parser";

export interface AnalysisNote {
  level: "info" | "warn" | "danger";
  cn: string;
  en: string;
}

export interface AnalysisResult {
  input: string;
  parse: ParseResult;
  found: boolean;                  // 是否在数据库中找到 / found in DB
  compound?: Compound;             // 数据库条目 / DB entry (if found)
  existence: "exists" | "likely" | "questionable" | "unlikely" | "invalid";
  existenceCn: string;
  existenceEn: string;
  nameCn?: string;
  nameEn?: string;
  categoryCn?: string;
  categoryEn?: string;
  mass: number;
  composition: Record<string, number>;
  notes: AnalysisNote[];
  colors?: CompoundColor[];        // 各形态下的颜色（固体/溶液/晶体等）
  elements: { symbol: string; name_cn: string; name_en: string; count: number; massPct: number }[];
  fromCache?: boolean;             // 是否来自 D1 缓存 / from D1 cache
}

const CAT_CN: Record<string, string> = {
  acid: "酸", base: "碱", oxide: "氧化物", salt: "盐", hydride: "氢化物",
  peroxide: "过氧化物", superoxide: "超氧化物", ozonide: "臭氧化物",
  coordination: "配合物", organic: "有机物", element: "单质",
  interhalogen: "卤素互化物", alloy: "合金", other: "其他",
};
const CAT_EN: Record<string, string> = {
  acid: "Acid", base: "Base", oxide: "Oxide", salt: "Salt", hydride: "Hydride",
  peroxide: "Peroxide", superoxide: "Superoxide", ozonide: "Ozonide",
  coordination: "Coordination compound", organic: "Organic", element: "Element",
  interhalogen: "Interhalogen", alloy: "Alloy", other: "Other",
};

const STATUS_CN: Record<string, string> = {
  stable: "稳定存在", conditional: "条件性存在", unstable: "不稳定", hypothetical: "假设/难孤立",
};
const STATUS_EN: Record<string, string> = {
  stable: "Stable", conditional: "Conditional", unstable: "Unstable", hypothetical: "Hypothetical",
};

export function analyzeFormula(input: string): AnalysisResult {
  const parse = parseFormula(input);
  const notes: AnalysisNote[] = [];

  // Compose element table & mass percentages
  const totalMass = parse.mass || 0;
  const elements = Object.entries(parse.composition)
    .map(([sym, count]) => {
      const el = ELEMENTS[sym];
      const m = el ? el.mass * count : 0;
      return {
        symbol: sym,
        name_cn: el?.name_cn ?? "?",
        name_en: el?.name_en ?? "?",
        count,
        massPct: totalMass > 0 ? (m / totalMass) * 100 : 0,
      };
    })
    .sort((a, b) => b.count - a.count);

  // Unparseable
  if (!parse.ok) {
    return {
      input,
      parse,
      found: false,
      existence: "invalid",
      existenceCn: "无法解析",
      existenceEn: "Unparseable",
      mass: parse.mass,
      composition: parse.composition,
      notes: [{ level: "danger", cn: parse.error ?? "化学式格式错误", en: parse.error ?? "Malformed formula" }],
      elements,
    };
  }

  // Unknown elements present
  if (parse.unknownElements.length > 0) {
    const syms = parse.unknownElements.join(", ");
    return {
      input,
      parse,
      found: false,
      existence: "invalid",
      existenceCn: "含未知元素",
      existenceEn: "Contains unknown elements",
      mass: parse.mass,
      composition: parse.composition,
      notes: [
        {
          level: "danger",
          cn: `未识别的元素符号：${syms}。请检查大小写（元素符号首字母大写，次字母小写，如 Na、Cl、Fe）。`,
          en: `Unrecognized element symbol(s): ${syms}. Check capitalization (symbols start uppercase, second letter lowercase, e.g. Na, Cl, Fe).`,
        },
      ],
      elements,
    };
  }

  // Try DB lookup
  // 有电荷时：构造带电候选形式查找（如 "Fe^3+" → "Fe3+", "Fe+3", "Fe+"），
  //   绝不 fallback 到去电荷的 normalized（会误命中单质 Fe 等元素）。
  // 无电荷时：按 normalized → original → 水合物首段顺序查。
  let compound: Compound | null = null;
  if (parse.charge && parse.charge !== 0) {
    compound = findCompoundByCharged(input, parse.original, parse.charge);
  } else {
    compound = findCompound(parse.normalized)
      ?? findCompound(input)
      ?? findCompound(parse.original)
      ?? findCompound(parse.hydrateParts[0] ?? "");
  }

  if (compound) {
    const notesFromDb: AnalysisNote[] = (compound.notes_cn.length === 0 && compound.notes_en.length === 0)
      ? []
      : compound.notes_cn.map((cn, i) => ({
          level: noteLevelFor(compound!.status, i),
          cn,
          en: compound!.notes_en[i] ?? cn,
        }));

    // Add a status header note
    const statusNote: AnalysisNote = {
      level: compound.status === "stable" ? "info" : compound.status === "conditional" ? "warn" : "danger",
      cn: `存在性：${STATUS_CN[compound.status]}。${compound.status === "stable" ? "常温常压下可稳定存在。" : compound.status === "conditional" ? "只在特定条件下存在。" : compound.status === "unstable" ? "常温下极不稳定，难以单独存在。" : "文献假设或极难孤立。"}`,
      en: `Existence: ${STATUS_EN[compound.status]}. ${compound.status === "stable" ? "Stable at STP." : compound.status === "conditional" ? "Exists only under special conditions." : compound.status === "unstable" ? "Very unstable at STP, hard to isolate." : "Hypothetical or extremely hard to isolate."}`,
    };

    return {
      input,
      parse,
      found: true,
      compound,
      existence: compound.status === "stable" ? "exists" : compound.status === "conditional" ? "likely" : "questionable",
      existenceCn: STATUS_CN[compound.status],
      existenceEn: STATUS_EN[compound.status],
      nameCn: compound.name_cn,
      nameEn: compound.name_en,
      categoryCn: CAT_CN[compound.category],
      categoryEn: CAT_EN[compound.category],
      mass: parse.mass,
      composition: parse.composition,
      notes: [statusNote, ...notesFromDb],
      colors: compound.colors,
      elements,
    };
  }

  // ---- Not in DB: general analysis for unknown-but-valid formula ----
  const analysis = analyzeUnknown(parse, elements);
  return {
    input,
    parse,
    found: false,
    existence: analysis.existence,
    existenceCn: analysis.existenceCn,
    existenceEn: analysis.existenceEn,
    mass: parse.mass,
    composition: parse.composition,
    notes: analysis.notes,
    elements,
  };
}

function noteLevelFor(status: string, _i: number): AnalysisNote["level"] {
  if (status === "stable") return "info";
  if (status === "conditional") return "warn";
  return "danger";
}

// 带电化学式查找：构造多种带电写法候选，逐一查 DB（命中离子条目而非单质）。
// candidates 顺序：原始输入 → 去除 ^ 的原样 → "Core3+/Core+3" 等规范形式
function findCompoundByCharged(input: string, original: string, charge: number): Compound | null {
  // 1) 原始输入（含 ^3+ / + 等写法，可能命中 alias）
  let c = findCompound(input) ?? findCompound(original);
  if (c) return c;

  // 2) 构造带电核心：取 original，剥离尾部电荷符号与状态，得到 core
  //    original 形如 "Fe^3+" / "SO4^2-" / "Na+" / "[Cu(NH3)4]2+"
  let core = original.replace(/\((s|l|g|aq)\)$/i, "").trim();
  core = core.replace(/\^([0-9]*[+-])$/, "").trim();
  // 尾随 + / - 与数字（紧跟在 ) ] } 或小写字母后）
  core = core.replace(/([\]\)\}a-z])(\d*[+-])$/, "$1").trim();

  const abs = Math.abs(charge);
  const sign = charge > 0 ? "+" : "-";
  const numStr = abs === 1 ? "" : String(abs);
  // 候选写法：Core3+ / Core+3 / Core3- / Core-3 / Core+ / Core-
  const candidates = [
    core + numStr + sign,   // Fe3+, SO42-
    core + sign + numStr,   // Fe+3, SO4-2
  ];
  // ±1 时也试 Core+ / Core-（已在 numStr="" 覆盖）
  for (const cand of candidates) {
    c = findCompound(cand);
    if (c) return c;
  }
  return null;
}

// Heuristic analysis of an unknown formula
function analyzeUnknown(
  parse: ParseResult,
  elements: { symbol: string; count: number }[]
): {
  existence: AnalysisResult["existence"];
  existenceCn: string;
  existenceEn: string;
  notes: AnalysisNote[];
} {
  const notes: AnalysisNote[] = [];
  const symbols = Object.keys(parse.composition);

  // Single element
  if (symbols.length === 1) {
    const sym = symbols[0];
    const el = ELEMENTS[sym];
    const count = parse.composition[sym];
    if (count === 1) {
      notes.push({
        level: "info",
        cn: `这是元素 ${el.name_cn}（${el.name_en}）的单原子形式。原子态在气相或等离子体中存在，常温下多以单质（如 ${singleElementAllotropeHint(sym)}）存在。`,
        en: `This is a single atom of ${el.name_en}. Atomic form exists in gas phase/plasma; at STP it usually occurs as ${singleElementAllotropeHintEn(sym)}.`,
      });
      return { existence: "likely", existenceCn: "单原子", existenceEn: "Single atom", notes };
    }
    notes.push({
      level: "info",
      cn: `这是 ${el.name_cn}（${el.name_en}）的同核双/多原子分子，可能是该元素的一种单质形态。`,
      en: `A homonuclear molecule of ${el.name_en}; possibly one of its elemental allotropes.`,
    });
    return { existence: "likely", existenceCn: "单质", existenceEn: "Element", notes };
  }

  // Noble gas in a compound (other than its own element)
  if (symbols.some((s) => ELEMENTS[s]?.category === "noble")) {
    const noble = symbols.filter((s) => ELEMENTS[s]?.category === "noble");
    notes.push({
      level: "warn",
      cn: `含稀有气体（${noble.map((s) => ELEMENTS[s].name_cn).join("、")}）。稀有气体化合物通常需要强氧化性元素（F/O）与高压/低温条件，多数日常条件下不存在。`,
      en: `Contains noble gas (${noble.map((s) => ELEMENTS[s].name_en).join(", ")}). Noble-gas compounds usually require strong oxidizers (F/O) and harsh conditions; most do not exist under ordinary conditions.`,
    });
    // He, Ne, Ar essentially never form stable compounds
    const impossible = noble.filter((s) => ["He", "Ne", "Ar"].includes(s));
    if (impossible.length > 0) {
      notes.push({
        level: "danger",
        cn: `${impossible.map((s) => ELEMENTS[s].name_cn).join("、")} 的化合物在常规化学条件下基本不存在（仅理论/极端条件）。`,
        en: `Compounds of ${impossible.map((s) => ELEMENTS[s].name_en).join(", ")} essentially do not exist under normal chemistry (theoretical/extreme conditions only).`,
      });
      return { existence: "unlikely", existenceCn: "极可能不存在", existenceEn: "Most likely does not exist", notes };
    }
    return { existence: "questionable", existenceCn: "条件性可能存在", existenceEn: "Possibly conditional", notes };
  }

  // 离子电荷提示
  if (parse.charge !== null && parse.charge !== 0) {
    const chargeStr = formatCharge(parse.charge);
    notes.push({
      level: "info",
      cn: `这是离子，带电荷 ${chargeStr}。`,
      en: `This is an ion with charge ${chargeStr}.`,
    });
  }
  // 状态标记提示
  if (parse.state) {
    const stateMap: Record<string, [string, string]> = {
      s: ["固态", "solid"], l: ["液态", "liquid"], g: ["气态", "gas"], aq: ["水溶液", "aqueous solution"],
    };
    const [cn, en] = stateMap[parse.state] ?? [parse.state, parse.state];
    notes.push({
      level: "info",
      cn: `状态标记：${cn}。`,
      en: `State: ${en}.`,
    });
  }

  // Try valence/oxidation-state feasibility (very rough)
  const valenceIssue = checkValenceFeasibility(parse.composition, parse.charge);
  if (valenceIssue) notes.push(valenceIssue);

  // Acid radical detection (common oxoanion patterns)
  const radical = detectCommonRadical(parse.composition);
  if (radical) {
    notes.push({
      level: "info",
      cn: radical.cn,
      en: radical.en,
    });
  }

  // Suggest it might be a valid but uncommon compound
  // (具体注意事项由联网 PubChem / AI 兜底给出，此处不再赘述)
  // If valence check passed, lean toward "likely"; otherwise "questionable"
  const existence = valenceIssue ? "questionable" : "likely";
  return {
    existence,
    existenceCn: existence === "likely" ? "可能存在" : "存疑",
    existenceEn: existence === "likely" ? "Likely exists" : "Questionable",
    notes,
  };
}

function singleElementAllotropeHint(sym: string): string {
  const map: Record<string, string> = {
    H: "H₂", O: "O₂", N: "N₂", F: "F₂", Cl: "Cl₂", Br: "Br₂", I: "I₂",
    P: "P₄（白磷）/ 红磷", S: "S₈", C: "金刚石/石墨",
  };
  return map[sym] ?? `金属 ${sym}`;
}
function singleElementAllotropeHintEn(sym: string): string {
  const map: Record<string, string> = {
    H: "H₂", O: "O₂", N: "N₂", F: "F₂", Cl: "Cl₂", Br: "Br₂", I: "I₂",
    P: "P₄ (white) / red P", S: "S₈", C: "diamond/graphite",
  };
  return map[sym] ?? `metallic ${sym}`;
}

// Very rough valence feasibility check.
// Strategy: assume O = -2, H = +1 (with metal) or -1 (with metal), F = -1, Cl/Br/I = -1 with metals/electropositive.
// Compute total negative/positive and see if remaining elements can take feasible oxidation states.
function checkValenceFeasibility(comp: Record<string, number>, charge: number | null): AnalysisNote | null {
  const syms = Object.keys(comp);
  if (syms.length < 2) return null;

  let fixed = 0; // sum of oxidation contributions from fixed elements
  const others: { el: ElementInfo; count: number }[] = [];

  if (comp["O"]) {
    fixed += -2 * comp["O"];
  }
  if (comp["H"]) {
    // H 的价态规则：
    // - 同时含 O（氧化物/氢氧化物/含氧酸）→ H 为 +1（形成 OH 或 H2O）
    // - 无 O 但有金属 → H 为 -1（氢化物，如 NaH、CaH2）
    // - 其他 → H 为 +1
    const hasO = !!comp["O"];
    const hasMetal = syms.some((s) => isMetal(ELEMENTS[s]));
    const hOx = hasO ? 1 : (hasMetal ? -1 : 1);
    fixed += hOx * comp["H"];
  }
  if (comp["F"]) {
    fixed += -1 * comp["F"];
  }

  for (const s of syms) {
    if (["O", "H", "F"].includes(s)) continue;
    const el = ELEMENTS[s];
    if (!el) continue;
    others.push({ el, count: comp[s] });
  }

  // The remaining oxidation sum must equal -(fixed) + (charge ?? 0)
  const target = -fixed + (charge ?? 0);

  // If only one "other" element, its oxidation state is target / count — must be in valences
  if (others.length === 1) {
    const { el, count } = others[0];
    const ox = target / count;
    // 非整数平均氧化态在多原子体系（如 C8H10 的碳）中是正常的，不报错
    if (!Number.isInteger(ox)) {
      return null;
    }
    if (!el.valences.includes(ox)) {
      return {
        level: "warn",
        cn: `价态校验：${el.name_cn} 需取 ${formatOx(ox)} 价，但常见价为 ${el.valences.map(formatOx).join("、")}。可能是少见/不稳定价态或化学式有误。`,
        en: `Valence check: ${el.name_en} would need oxidation state ${formatOx(ox)}, but common states are ${el.valences.map(formatOx).join(", ")}. Could be a rare/unstable state or a wrong formula.`,
      };
    }
    return null;
  }

  // Multiple other elements — we cannot easily verify; just give a neutral note if any element has no feasible integer solution trivially
  return null;
}

function formatOx(n: number): string {
  if (n === 0) return "0";
  return n > 0 ? `+${n}` : `${n}`;
}

// 格式化电荷：+2 → "2⁺"，-2 → "2⁻"，+1 → "⁺"，-1 → "⁻"
function formatCharge(c: number): string {
  const sign = c > 0 ? "⁺" : "⁻";
  const abs = Math.abs(c);
  return (abs === 1 ? "" : String(abs)) + sign;
}

function isMetal(el?: ElementInfo): boolean {
  if (!el) return false;
  return ["alkali-metal", "alkaline-earth", "transition", "post-transition", "lanthanide", "actinide"].includes(el.category);
}

// Detect common acid radicals / functional groups by composition
function detectCommonRadical(comp: Record<string, number>): { cn: string; en: string } | null {
  const has = (s: string, n: number) => (comp[s] ?? 0) >= n;
  const get = (s: string) => comp[s] ?? 0;

  // Sulfate SO4
  if (has("S", 1) && has("O", 4) && get("S") * 4 === get("O") - (get("H") || 0) * 0) {
    // sulfate-ish if S:O = 1:4
    if (get("S") === 1 && get("O") === 4) return { cn: "含硫酸根 SO₄²⁻ 结构", en: "Contains sulfate SO₄²⁻ group" };
  }
  if (get("S") === 1 && get("O") === 3) return { cn: "含亚硫酸根 SO₃²⁻ 结构", en: "Contains sulfite SO₃²⁻ group" };
  if (get("N") === 1 && get("O") === 3) return { cn: "含硝酸根 NO₃⁻ 结构", en: "Contains nitrate NO₃⁻ group" };
  if (get("N") === 1 && get("O") === 2) return { cn: "含亚硝酸根 NO₂⁻ 结构", en: "Contains nitrite NO₂⁻ group" };
  if (get("P") === 1 && get("O") === 4) return { cn: "含磷酸根 PO₄³⁻ 结构", en: "Contains phosphate PO₄³⁻ group" };
  if (get("Cl") === 1 && get("O") === 4) return { cn: "含高氯酸根 ClO₄⁻ 结构", en: "Contains perchlorate ClO₄⁻ group" };
  if (get("Cl") === 1 && get("O") === 3) return { cn: "含氯酸根 ClO₃⁻ 结构", en: "Contains chlorate ClO₃⁻ group" };
  if (get("Cl") === 1 && get("O") === 1) return { cn: "含次氯酸根 ClO⁻ 结构", en: "Contains hypochlorite ClO⁻ group" };
  if (get("C") === 1 && get("O") === 3) return { cn: "含碳酸根 CO₃²⁻ 结构", en: "Contains carbonate CO₃²⁻ group" };
  if (get("Mn") === 1 && get("O") === 4) return { cn: "含高锰酸根 MnO₄⁻ 结构", en: "Contains permanganate MnO₄⁻ group" };
  if (get("Fe") === 1 && get("O") === 4) return { cn: "含高铁酸根 FeO₄²⁻ 结构", en: "Contains ferrate FeO₄²⁻ group" };
  if (get("Cr") === 1 && get("O") === 4) return { cn: "含铬酸根 CrO₄²⁻ 结构", en: "Contains chromate CrO₄²⁻ group" };
  if (get("Cr") === 1 && get("O") === 3) return { cn: "含亚铬酸根 CrO₃²⁻ 结构", en: "Contains chromite CrO₃²⁻ group" };
  if (get("Cl") === 1 && get("O") === 2) return { cn: "含亚氯酸根 ClO₂⁻ 结构", en: "Contains chlorite ClO₂⁻ group" };
  if (get("Br") === 1 && get("O") === 3) return { cn: "含溴酸根 BrO₃⁻ 结构", en: "Contains bromate BrO₃⁻ group" };
  if (get("I") === 1 && get("O") === 3) return { cn: "含碘酸根 IO₃⁻ 结构", en: "Contains iodate IO₃⁻ group" };
  if (get("I") === 1 && get("O") === 4) return { cn: "含高碘酸根 IO₄⁻ 结构", en: "Contains periodate IO₄⁻ group" };
  return null;
}
