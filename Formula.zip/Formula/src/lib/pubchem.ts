// PubChem REST API 客户端 / PubChem REST API client
// 当本地数据库未命中时，调用 PubChem 联网查询化合物信息。
// 文档: https://pubchem.ncbi.nlm.nih.gov/docs/pug-rest
// 限速: 5 req/s (无 API key)，从 Worker(CF 边缘) 访问 NCBI，国内可达性不受影响。

const PUBCHEM_BASE = "https://pubchem.ncbi.nlm.nih.gov/rest/pug";

export interface PubChemCompound {
  cid: number;                  // PubChem Compound ID
  molecularFormula: string;     // 规范化化学式
  molecularWeight: number;
  iupacName?: string;
  title?: string;
  canonicalSmiles?: string;
  synonymCount?: number;
}

export interface PubChemResult {
  ok: boolean;
  source: "pubchem";
  queryFormula: string;
  hits: PubChemCompound[];       // 同分异构体列表（已按相关性截断）
  note: { cn: string; en: string };
}

// 按化学式查询 PubChem
// PubChem 分子式查询是异步的：结果集大时返回 { Waiting: { ListKey } }，需要轮询 listkey 接口。
export async function searchByFormula(
  formula: string,
  opts: { maxHits?: number; timeoutMs?: number } = {}
): Promise<PubChemResult> {
  const maxHits = opts.maxHits ?? 5;
  const timeoutMs = opts.timeoutMs ?? 8000;

  const clean = formula.replace(/\s+/g, "");
  const pure = stripToPureFormula(clean);
  if (!pure) {
    return { ok: false, source: "pubchem", queryFormula: formula, hits: [], note: { cn: "化学式无法规整为纯元素式，跳过联网查询", en: "Formula could not be reduced to a pure elemental form; skipped online lookup" } };
  }

  const props = "MolecularFormula,MolecularWeight,IUPACName,Title,CanonicalSMILES";
  const initialUrl = `${PUBCHEM_BASE}/compound/formula/${encodeURIComponent(pure)}/property/${props}/JSON?MaxRecords=${maxHits * 2}`;

  const deadline = Date.now() + timeoutMs;

  try {
    let url = initialUrl;
    let polls = 0;
    // 最多轮询 4 次（处理 PubChem 的异步 ListKey 机制）
    while (Date.now() < deadline && polls < 4) {
      polls++;
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), Math.min(4000, deadline - Date.now()));
      let resp: Response;
      try {
        resp = await fetch(url, {
          signal: ctrl.signal,
          headers: { "Accept": "application/json", "User-Agent": "FormulaAtlas/1.0 (Cloudflare Worker; chemistry tool)" },
        });
      } finally {
        clearTimeout(timer);
      }

      if (resp.status === 404 || resp.status === 400) {
        // 404 = 明确无此分子式；400 = listkey 过期或该分子式无对应化合物（PubChem 对空结果常返回 400）
        return { ok: false, source: "pubchem", queryFormula: formula, hits: [], note: { cn: "PubChem 数据库中未找到该分子式的化合物", en: "No compounds with this formula found in PubChem" } };
      }
      if (resp.status === 503 || resp.status === 504) {
        return { ok: false, source: "pubchem", queryFormula: formula, hits: [], note: { cn: "PubChem 服务暂时不可用（限速/超时）", en: "PubChem service temporarily unavailable (rate limit/timeout)" } };
      }
      if (!resp.ok) {
        return { ok: false, source: "pubchem", queryFormula: formula, hits: [], note: { cn: `PubChem 查询失败 (HTTP ${resp.status})`, en: `PubChem query failed (HTTP ${resp.status})` } };
      }

      const json: any = await resp.json();

      // 异步任务未完成 —— 用 ListKey 轮询
      if (json?.Waiting?.ListKey) {
        const listKey = json.Waiting.ListKey;
        url = `${PUBCHEM_BASE}/compound/listkey/${listKey}/property/${props}/JSON`;
        await sleep(700);
        continue;
      }

      const rows: any[] = json?.PropertyTable?.Properties ?? [];
      if (rows.length === 0) {
        return { ok: false, source: "pubchem", queryFormula: formula, hits: [], note: { cn: "PubChem 返回空结果", en: "PubChem returned no results" } };
      }

      const hits: PubChemCompound[] = rows.slice(0, maxHits).map((r) => ({
        cid: r.CID,
        molecularFormula: r.MolecularFormula,
        molecularWeight: r.MolecularWeight,
        iupacName: r.IUPACName,
        title: r.Title,
        canonicalSmiles: r.CanonicalSMILES,
      }));

      return {
        ok: true,
        source: "pubchem",
        queryFormula: formula,
        hits,
        note: {
          cn: `已联网查询 PubChem（美国国家化学数据库，收录 1.1 亿+ 化合物），命中 ${rows.length} 条同分异构体记录。`,
          en: `Online lookup via PubChem (NCBI, 110M+ compounds) returned ${rows.length} isomer record(s).`,
        },
      };
    }

    // 轮询超时
    return { ok: false, source: "pubchem", queryFormula: formula, hits: [], note: { cn: "PubChem 查询超时（异步任务未完成）", en: "PubChem query timed out (async task did not complete)" } };
  } catch (err: any) {
    const aborted = err?.name === "AbortError";
    return {
      ok: false,
      source: "pubchem",
      queryFormula: formula,
      hits: [],
      note: {
        cn: aborted ? "PubChem 查询超时" : `联网查询失败：${err?.message ?? String(err)}`,
        en: aborted ? "PubChem query timed out" : `Online lookup failed: ${err?.message ?? String(err)}`,
      },
    };
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

// 获取某 CID 的同义词（名称），用于补充名称信息
export async function getSynonyms(cid: number, timeoutMs = 5000): Promise<string[]> {
  const url = `${PUBCHEM_BASE}/compound/cid/${cid}/synonyms/TXT`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const resp = await fetch(url, { signal: ctrl.signal, headers: { "Accept": "text/plain" } });
    if (!resp.ok) return [];
    const text = await resp.text();
    return text.split("\n").map((s) => s.trim()).filter(Boolean).slice(0, 12);
  } catch {
    return [];
  } finally {
    clearTimeout(timer);
  }
}

// 把化学式剥成 PubChem 能接受的形式：只保留元素符号与数字，去掉水合物点号、电荷、状态、括号外的系数等
// 注意：括号保留（PubChem 支持 (CH3)2 这种），但水合物分隔符与电荷要去掉。
function stripToPureFormula(s: string): string {
  // 去状态后缀 (s)(l)(g)(aq)
  let out = s.replace(/\((s|l|g|aq)\)$/i, "");
  // 去电荷 ^2- / ^+ / 尾随 +/-
  out = out.replace(/\^([0-9]*[+-])$/, "");
  out = out.replace(/([\]\)\}a-z])(\d*[+-])$/, (m, p1) => p1);
  // 水合物：取第一段（PubChem 用单分子式查询更可靠）
  out = out.split(/[·•*]/)[0] || out;
  // 去前导系数
  out = out.replace(/^(\d+)\s*/, "");
  // 只保留字母、数字、括号
  out = out.replace(/[^A-Za-z0-9()\[\]{}]/g, "");
  return out.trim();
}
