// 联网百科搜索源 / Online encyclopedia search
// 主源: Wikipedia（Worker 在境外节点，可稳定访问）
// 兜底: WikiData wbsearchentities（与 Wikipedia 独立的服务，中英文实体标签+描述）
// 当 Wikipedia 未命中或限流时，自动回退到 WikiData，保证 AI 有稳定事实背景。
// 注: 百度百科等国内百科有反爬验证，从 Worker 抓取不稳定，故未采用。

export interface WikiHit {
  title: string;
  lang: "zh" | "en";
  extract: string;   // 摘要（纯文本，已截断）
  url: string;
  source: "wikipedia" | "wikidata";
}

export interface WikiResult {
  ok: boolean;
  query: string;
  zh?: WikiHit;
  en?: WikiHit;
}

const EXTRACT_MAX = 600;
const UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";

// 先用名称/化学式搜，中英文并行，各自带回退
export async function searchWiki(query: string, timeoutMs = 6000): Promise<WikiResult> {
  if (!query) return { ok: false, query };
  const [zh, en] = await Promise.all([
    searchOneLangWithFallback(query, "zh", timeoutMs),
    searchOneLangWithFallback(query, "en", timeoutMs),
  ]);
  return { ok: !!(zh || en), query, zh: zh ?? undefined, en: en ?? undefined };
}

// 按名称查（PubChem 命中后用英文名搜英文 Wikipedia，用化学式搜中文）
export async function searchWikiByName(nameEn: string, formula: string, timeoutMs = 6000): Promise<WikiResult> {
  const [en, zhByName, zhByFormula] = await Promise.all([
    nameEn ? searchOneLangWithFallback(nameEn, "en", timeoutMs) : Promise.resolve(null),
    nameEn ? searchOneLangWithFallback(nameEn, "zh", timeoutMs) : Promise.resolve(null),
    searchOneLangWithFallback(formula, "zh", timeoutMs),
  ]);
  const zh = zhByName ?? zhByFormula;
  return { ok: !!(zh || en), query: nameEn || formula, zh: zh ?? undefined, en: en ?? undefined };
}

// 单语言查询 + 回退：Wikipedia → WikiData
async function searchOneLangWithFallback(query: string, lang: "zh" | "en", timeoutMs: number): Promise<WikiHit | null> {
  let hit = await searchWikipediaOneLang(query, lang, timeoutMs).catch(() => null);
  if (hit) return hit;

  // 兜底：WikiData（与 Wikipedia 独立，中英文均可）
  hit = await searchWikidata(query, lang, timeoutMs).catch(() => null);
  return hit;
}

// ---- Wikipedia ----
async function searchWikipediaOneLang(query: string, lang: "zh" | "en", timeoutMs: number): Promise<WikiHit | null> {
  const apiBase = lang === "zh" ? "https://zh.wikipedia.org/w/api.php" : "https://en.wikipedia.org/w/api.php";
  const restBase = lang === "zh" ? "https://zh.wikipedia.org/api/rest_v1/page/summary/" : "https://en.wikipedia.org/api/rest_v1/page/summary/";

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);

  try {
    const searchUrl = `${apiBase}?action=query&list=search&srsearch=${encodeURIComponent(query)}&srlimit=1&format=json&origin=*`;
    const sResp = await fetch(searchUrl, { signal: ctrl.signal, headers: { Accept: "application/json" } });
    if (!sResp.ok) return null;
    const sJson: any = await sResp.json();
    const title: string | undefined = sJson?.query?.search?.[0]?.title;
    if (!title) return null;

    const sumUrl = `${restBase}${encodeURIComponent(title.replace(/ /g, "_"))}`;
    const mResp = await fetch(sumUrl, { signal: ctrl.signal, headers: { Accept: "application/json" } });
    if (!mResp.ok) {
      const snippet: string = sJson?.query?.search?.[0]?.snippet ?? "";
      return {
        title,
        lang,
        extract: stripHtml(snippet).slice(0, EXTRACT_MAX),
        url: lang === "zh" ? `https://zh.wikipedia.org/wiki/${encodeURIComponent(title)}` : `https://en.wikipedia.org/wiki/${encodeURIComponent(title)}`,
        source: "wikipedia",
      };
    }
    const mJson: any = await mResp.json();
    const extract: string = mJson?.extract ?? "";
    return {
      title: mJson?.title ?? title,
      lang,
      extract: stripHtml(extract).slice(0, EXTRACT_MAX),
      url: mJson?.content_urls?.desktop?.page ?? (lang === "zh" ? `https://zh.wikipedia.org/wiki/${encodeURIComponent(title)}` : `https://en.wikipedia.org/wiki/${encodeURIComponent(title)}`),
      source: "wikipedia",
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// ---- WikiData（独立兜底）----
async function searchWikidata(query: string, lang: "zh" | "en", timeoutMs: number): Promise<WikiHit | null> {
  const url = `https://www.wikidata.org/w/api.php?action=wbsearchentities&search=${encodeURIComponent(query)}&language=${lang}&format=json&limit=1&origin=*`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const resp = await fetch(url, { signal: ctrl.signal, headers: { "User-Agent": UA, Accept: "application/json" } });
    if (!resp.ok) return null;
    const json: any = await resp.json();
    const ent = json?.search?.[0];
    if (!ent) return null;
    const label: string = ent.label || "";
    const desc: string = ent.description || "";
    if (!label && !desc) return null;
    return {
      title: label,
      lang,
      extract: [label, desc].filter(Boolean).join("："),
      url: `https://www.wikidata.org/wiki/${ent.id}`,
      source: "wikidata",
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function stripHtml(s: string): string {
  return s
    .replace(/<[^>]+>/g, "")
    .replace(/&[a-z]+;/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}
