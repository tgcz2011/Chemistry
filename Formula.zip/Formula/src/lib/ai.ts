// Workers AI 推断 / Workers AI inference
// 模型: @cf/qwen/qwen3-30b-a3b-fp8（用户指定）
// 职责: 基于 PubChem + Wikipedia 事实，总结注意事项 + 判断存在性 + 给名称 + 给颜色。
// 输出明确、确定，避免"可能"堆叠；标注"仅供参考"。

import type { WikiResult } from "./wiki";
import type { CompoundColor } from "../data/compounds";

interface Env {
  AI: any;
}

export interface AiNote {
  level: "info" | "warn" | "danger";
  cn: string;
  en: string;
}

export interface AiVerdict {
  ok: boolean;
  existence: "likely" | "questionable" | "unlikely";
  nameCn?: string;
  nameEn?: string;
  notes: AiNote[];          // AI 总结的注意事项（2-4 条）
  colors?: CompoundColor[]; // 各形态下的颜色（固体/溶液/晶体/气体等）
  errorCn?: string;
  errorEn?: string;
}

const MODEL = "@cf/qwen/qwen3-30b-a3b-fp8";

export interface AiContext {
  formula: string;
  composition: Record<string, number>;
  mass: number;
  pubchem?: { name?: string; cid?: number; isomers?: number } | null;
  wiki?: WikiResult | null;
  // 本地分析器检测到的结构提示（酸根、价态等），作为事实补充
  localHints?: string[];
  // 刷新模式：已有旧注意事项，让 AI 在此基础上补充/修正
  refresh?: { oldNotes?: AiNote[] } | null;
  // 离子标志：当 charge != null 且 != 0 时为离子，AI 应给离子性质而非单质
  charge?: number | null;
}

export async function aiJudgeFormula(env: Env, ctx: AiContext): Promise<AiVerdict> {
  if (!env?.AI) {
    return { ok: false, existence: "questionable", notes: [], errorCn: "AI 服务未绑定", errorEn: "AI binding unavailable" };
  }

  const elems = Object.entries(ctx.composition).map(([s, n]) => `${s}×${n}`).join(", ");

  // 离子感知：charge 非空且非 0 时为离子
  const charge = ctx.charge ?? 0;
  const isIon = charge !== 0;
  const ionLine = isIon
    ? `\n重要：该化学式带电荷 ${formatCharge(charge)}，是一个离子，不是中性化合物，更不是单质。请给出该离子的性质（水溶液颜色、常见检验反应、与沉淀剂的反应、氧化还原性等），不要描述成单质元素的性质。`
    : "";

  // 拼装事实背景
  const facts: string[] = [];
  const pc = ctx.pubchem;
  if (pc?.name) {
    facts.push(`PubChem 已证实该化学式存在${pc.cid ? `（CID ${pc.cid}）` : ""}，名称: ${pc.name}${pc.isomers ? `，共 ${pc.isomers} 种同分异构体` : ""}。`);
  } else {
    facts.push("PubChem 未找到该化学式。");
  }
  if (ctx.wiki?.zh?.extract) facts.push(`中文维基百科条目《${ctx.wiki.zh.title}》：${ctx.wiki.zh.extract}`);
  if (ctx.wiki?.en?.extract) facts.push(`英文维基百科条目《${ctx.wiki.en.title}》：${ctx.wiki.en.extract}`);
  if (ctx.localHints?.length) facts.push(`本地结构分析：${ctx.localHints.join("；")}。`);

  const refreshLine = ctx.refresh?.oldNotes?.length
    ? `\n已有注意事项（请在此基础上补充或修正，不要简单重复）：\n${ctx.refresh.oldNotes.map((n) => `- ${n.cn}`).join("\n")}`
    : "";

  const system = `你是严谨的化学参考助手。基于已提供的 PubChem 与维基百科事实，针对给定化学式完成：
(1) 判断该物质是否真实可分离存在；
(2) 给出该物质的中英文名称（若确实不存在则留空）；
(3) 总结 2-4 条简明的注意事项（稳定性、保存、毒性、反应性、制取等，按相关性给）；
(4) 给出该物质的颜色（按形态分类，如无水固体/水合物晶体/水溶液/气体等）。

要求：
- 表述要明确、确定，基于已给事实下结论；禁止堆砌"可能""也许""大概"等模糊词。若事实不足以下定论，直接说明"现有资料不足，建议查阅专业文献"，不要编造。
- 注意事项要具体、实用，给出可操作的结论（如"易燃，远离火源"而非"可能易燃"）。
- 若物质不存在，notes 里说明为何不存在 / 会分解成什么。
- 重要：PubChem 未找到某化学式，不等于该物质不存在。PubChem 按规范化式匹配，许多无机盐、配合物、水合物、同位素标记物在 PubChem 中以不同形式登记或不收录。请结合化学式本身、元素组成、价态、你对已知化合物的知识综合判断，不要仅因 PubChem 未命中就判定"不存在"。例如 Na2FeO4（高铁酸钠）、K2MnO4 等过渡金属高价含氧酸盐虽可能在 PubChem 中搜不到，但确为已知化合物。
- 名称要求：name_cn 必须是规范的中文化学名（如"硫酸""氢氧化钠""高铁酸钠""铁酸钠"），不要直接复制英文 IUPAC 名或 PubChem 的英文名。若事实中无中文名，请根据化学式组成、金属与非金属、价态、酸根，按中文无机命名规则（某某化某、某酸某、某酸氢某、高/亚某酸某等）推算。例如 NaFeO2（Fe+3）为"铁酸钠"，Na2FeO4（Fe+6）为"高铁酸钠"。推算出的中文名在未证伪前视为有效。
- 注意事项 notes 至少给 2 条，不要留空数组。
- 颜色 colors：尽量给出该物质在不同形态下的颜色（如无水固体、水合物晶体、水溶液、气体），每项含 ctx_cn（形态中文，如"无水固体"/"水溶液"/"晶体"/"气体"）、ctx_en（形态英文）、cn（颜色中文，如"白色"/"蓝色"/"紫黑色"）、en（颜色英文）、hex（代表性十六进制色值，如"#1e90ff"，无确切值时给最接近的纯色）。若该物质确无显著颜色（如无色气体/无色溶液），仍给出 colors: [{ctx_cn:"气体",ctx_en:"gas",cn:"无色",en:"colorless",hex:"#f5f5f0"}]。若完全无资料可留空数组。
- 严格只输出一个 JSON 对象，不要任何额外文字、不要 markdown 代码块标记。键: "existence"("likely"|"questionable"|"unlikely"), "name_cn", "name_en", "notes"(数组,每项含"level"∈"info"|"warn"|"danger","cn","en"), "colors"(数组,每项含"ctx_cn","ctx_en","cn","en","hex")。
- 每条备注末尾无需加"仅供参考"（系统会统一加）。`;

  const user = `化学式: ${ctx.formula}
元素组成: ${elems}
近似摩尔质量: ${ctx.mass.toFixed(2)} g/mol${ionLine}

已知事实:
${facts.join("\n")}${refreshLine}

请输出 JSON。`;

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 30000);

  try {
    const result: any = await env.AI.run(
      MODEL,
      {
        messages: [
          { role: "system", content: system },
          { role: "user", content: user + "\n\n直接输出 JSON 对象，以 { 开头，不要任何思考过程或解释。" },
        ],
        temperature: 0.1,
        max_tokens: 2500,
        response_format: { type: "json_object" },
        enable_thinking: false,
      },
      { signal: ctrl.signal as any }
    );

    let raw: string;
    if (typeof result === "string") raw = result;
    else if (result && typeof result.response === "string") raw = result.response;
    else if (result?.choices?.[0]?.message?.content) raw = result.choices[0].message.content;
    else if (result?.choices?.[0]?.message?.reasoning) raw = result.choices[0].message.reasoning;
    else raw = JSON.stringify(result ?? {});

    const parsed = safeParse(raw);
    if (!parsed) {
      return { ok: false, existence: "questionable", notes: [], errorCn: "AI 返回格式异常", errorEn: "AI returned malformed output" };
    }

    const ex = (parsed.existence === "likely" || parsed.existence === "unlikely") ? parsed.existence : "questionable";
    const nameCn = strOrUndef(parsed.name_cn);
    const nameEn = strOrUndef(parsed.name_en);

    const rawNotes: any[] = Array.isArray(parsed.notes) ? parsed.notes : [];
    const tag = "（AI 推断，仅供参考，请以专业数据库/文献为准）";
    const tagEn = " (AI inference, for reference only — verify with authoritative sources)";
    const notes: AiNote[] = rawNotes
      .map((n) => {
        const cn = strOrUndef(n?.cn);
        let en = strOrUndef(n?.en);
        // en 为空时用 cn 兜底（中文模型可能只输出 cn）
        if (!en && cn) en = cn;
        if (!cn) return null;
        return {
          level: (n?.level === "warn" || n?.level === "danger") ? n.level : "info",
          cn: cn + tag,
          en: en + tagEn,
        };
      })
      .filter((n): n is AiNote => n !== null && !!n.cn && !!n.en)
      .slice(0, 4);

    // 解析颜色数组（按形态分类）
    const rawColors: any[] = Array.isArray(parsed.colors) ? parsed.colors : [];
    const colors: CompoundColor[] = rawColors
      .map((c): CompoundColor | null => {
        const ctxCn = strOrUndef(c?.ctx_cn);
        const ctxEn = strOrUndef(c?.ctx_en);
        const cn = strOrUndef(c?.cn);
        let en = strOrUndef(c?.en);
        if (!en && cn) en = cn;
        if (!ctxCn || !cn) return null;
        const hex = sanitizeHex(c?.hex);
        const item: CompoundColor = { ctx_cn: ctxCn, ctx_en: ctxEn || ctxCn, cn, en: en || cn };
        if (hex) item.hex = hex;
        return item;
      })
      .filter((c): c is CompoundColor => c !== null)
      .slice(0, 6);

    return { ok: true, existence: ex, nameCn, nameEn, notes, colors: colors.length ? colors : undefined };
  } catch (err: any) {
    const aborted = err?.name === "AbortError";
    return {
      ok: false,
      existence: "questionable",
      notes: [],
      errorCn: aborted ? "AI 推断超时" : `AI 推断失败：${err?.message ?? String(err)}`,
      errorEn: aborted ? "AI inference timed out" : `AI inference failed: ${err?.message ?? String(err)}`,
    };
  } finally {
    clearTimeout(timer);
  }
}

// 格式化电荷：+2 → "2⁺"，-2 → "2⁻"，+1 → "⁺"，-1 → "⁻"
function formatCharge(c: number): string {
  const sign = c > 0 ? "⁺" : "⁻";
  const abs = Math.abs(c);
  return (abs === 1 ? "" : String(abs)) + sign;
}

// 清洗 hex 色值：仅接受 #rrggbb / #rgb，否则 undefined
function sanitizeHex(v: any): string | undefined {
  if (typeof v !== "string") return undefined;
  const s = v.trim();
  if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(s)) return s.toLowerCase();
  return undefined;
}

function strOrUndef(v: any): string | undefined {
  if (v == null) return undefined;
  const s = String(v).trim();
  return s || undefined;
}

function safeParse(s: string): any | null {
  if (!s) return null;
  // 去除 thinking 标签
  let cleaned = s.replace(/<think>[\s\S]*?<\/think>/gi, "");
  cleaned = cleaned.replace(/<think>[\s\S]*$/i, "");
  const thinkEnd = s.lastIndexOf("</think>");
  if (thinkEnd >= 0) cleaned = s.slice(thinkEnd + "</think>".length);
  // 去除 markdown 代码块标记 ```json ... ``` 或 ``` ... ```
  cleaned = cleaned.replace(/```(?:json|JSON)?\s*/g, "").replace(/```\s*/g, "");

  // 优先找包含 "existence" 的 JSON 对象（避免思考文本中的 { 干扰）
  // 从最后一个 "existence" 出现处往前找最近的 {
  const exIdx = cleaned.lastIndexOf('"existence"');
  if (exIdx > 0) {
    // 往前找最近的 {
    let startIdx = -1;
    for (let i = exIdx; i >= 0; i--) {
      if (cleaned[i] === "{") { startIdx = i; break; }
    }
    if (startIdx >= 0) {
      const endIdx = cleaned.lastIndexOf("}");
      if (endIdx > startIdx) {
        const slice = cleaned.slice(startIdx, endIdx + 1);
        const r = tryParseJson(slice);
        if (r) return r;
      }
    }
  }

  // 兜底：取最后一个 { 到最后一个 }（更可能是结果而非思考）
  const lastStart = cleaned.lastIndexOf("{");
  const lastEnd = cleaned.lastIndexOf("}");
  if (lastStart >= 0 && lastEnd > lastStart) {
    // 从 lastStart 往前扩展，尝试找到完整 JSON
    const slice = cleaned.slice(lastStart, lastEnd + 1);
    const r = tryParseJson(slice);
    if (r) return r;
  }

  // 最后兜底：第一个 { 到最后一个 }
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end < 0 || end <= start) return null;
  return tryParseJson(cleaned.slice(start, end + 1));
}

function tryParseJson(slice: string): any | null {
  try {
    return JSON.parse(slice);
  } catch {
    // 修复尾随逗号
    try {
      return JSON.parse(slice.replace(/,(\s*[}\]])/g, "$1"));
    } catch {
      return null;
    }
  }
}
