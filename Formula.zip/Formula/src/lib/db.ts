// D1 缓存 / D1 cache helper
// 缓存「本地 DB 未命中 → 联网(PubChem+Wiki+AI)」的分析结果，避免二次查询。
// 本地 DB 命中的化学式不缓存（瞬时返回）。
// 14 天后缓存标记为 stale，触发 AI 重新补充注意事项并更新。

import type { AnalysisResult } from "./analyzer";

interface Env {
  DB: any;
}

const STALE_MS = 14 * 24 * 60 * 60 * 1000; // 14 天

// 用作缓存 key 的规范化化学式：统一大小写、去状态符号/空格/水合物点号差异。
// 保留电荷信息（规范化为 "core|+n" / "core|-n"），避免 Co2+ 与 Co3+ 共享同一 key。
export function cacheKey(formula: string): string {
  let k = formula.trim();
  k = k.replace(/\((s|l|g|aq)\)$/i, "");
  k = k.replace(/[•*]/g, "·");
  k = k.replace(/\s+/g, "");

  // 提取并规范化电荷：^2- / ^+ / 2- / 3+ / + / -（尾随）
  let chargeSuffix = "";
  const caret = k.match(/\^([0-9]*[+-])$/);
  if (caret) {
    chargeSuffix = "|" + normalizeCharge(caret[1]);
    k = k.slice(0, caret.index);
  } else {
    const tail = k.match(/([\]\)\}a-z])(\d*[+-])$/);
    if (tail) {
      chargeSuffix = "|" + normalizeCharge(tail[2]);
      k = k.slice(0, tail.index! + 1);
    }
  }
  return k.toLowerCase() + chargeSuffix;
}

function normalizeCharge(s: string): string {
  const sign = s.endsWith("+") ? "+" : "-";
  const n = s.replace(/[+-]/g, "");
  const num = n === "" ? 1 : parseInt(n, 10);
  return (sign === "+" ? "+" : "-") + num;
}

export interface CachedEntry {
  result: AnalysisResult;
  stale: boolean;        // 是否超过 14 天（需 AI 重新补充）
  updatedAt: number;
}

// 读缓存：命中返回结果 + 是否过期
export async function getCached(env: Env, formula: string): Promise<CachedEntry | null> {
  if (!env?.DB) return null;
  const key = cacheKey(formula);
  if (!key) return null;
  try {
    const row = await env.DB.prepare("SELECT result_json, updated_at FROM formula_cache WHERE formula = ?").bind(key).first();
    if (!row?.result_json) return null;
    const parsed = JSON.parse(row.result_json) as AnalysisResult;
    if (parsed && Array.isArray(parsed.notes)) parsed.fromCache = true;
    const updatedAt = Number(row.updated_at) || 0;
    const stale = Date.now() - updatedAt > STALE_MS;
    return { result: parsed, stale, updatedAt };
  } catch {
    return null;
  }
}

// 写缓存：upsert 一条
export async function setCached(env: Env, formula: string, result: AnalysisResult): Promise<void> {
  if (!env?.DB) return;
  const key = cacheKey(formula);
  if (!key) return;
  const now = Date.now();
  try {
    await env.DB.prepare(
      "INSERT INTO formula_cache (formula, existence, name_cn, name_en, category_cn, category_en, mass, result_json, created_at, updated_at) " +
      "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " +
      "ON CONFLICT(formula) DO UPDATE SET existence=excluded.existence, name_cn=excluded.name_cn, name_en=excluded.name_en, category_cn=excluded.category_cn, category_en=excluded.category_en, mass=excluded.mass, result_json=excluded.result_json, updated_at=excluded.updated_at"
    )
      .bind(
        key,
        result.existence,
        result.nameCn ?? null,
        result.nameEn ?? null,
        result.categoryCn ?? null,
        result.categoryEn ?? null,
        result.mass ?? null,
        JSON.stringify(result),
        now,
        now
      )
      .run();
  } catch {
    /* 缓存写入失败不影响主流程 */
  }
}

// ===== 上报限流 =====
// 规则：同一设备每日总共 ≤ 20 次，单化学式每日 ≤ 3 次

const DAILY_TOTAL_LIMIT = 20;
const DAILY_FORMULA_LIMIT = 3;

export interface ReportLimitResult {
  allowed: boolean;
  reason?: "daily_total" | "formula_total";
  dailyUsed: number;
  formulaUsed: number;
  dailyLimit: number;
  formulaLimit: number;
}

// 检查并自增上报计数（原子操作）
export async function checkAndIncrReport(env: Env, deviceId: string, formula: string): Promise<ReportLimitResult> {
  if (!env?.DB || !deviceId) {
    // 无 D1 或无设备 ID 时放行（不阻塞主流程，但无限流保护）
    return { allowed: true, dailyUsed: 0, formulaUsed: 0, dailyLimit: DAILY_TOTAL_LIMIT, formulaLimit: DAILY_FORMULA_LIMIT };
  }
  const key = cacheKey(formula);
  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

  try {
    // 查当日该设备总量 + 该化学式计数（一条 SQL）
    const row = await env.DB.prepare(
      "SELECT " +
      "  COALESCE(SUM(CASE WHEN report_date = ? THEN count ELSE 0 END), 0) AS daily_used, " +
      "  COALESCE(MAX(CASE WHEN formula = ? AND report_date = ? THEN count ELSE 0 END), 0) AS formula_used " +
      "FROM report_usage WHERE device_id = ? AND report_date = ?"
    ).bind(today, key, today, deviceId, today).first();

    const dailyUsed = Number(row?.daily_used) || 0;
    const formulaUsed = Number(row?.formula_used) || 0;

    if (dailyUsed >= DAILY_TOTAL_LIMIT) {
      return { allowed: false, reason: "daily_total", dailyUsed, formulaUsed, dailyLimit: DAILY_TOTAL_LIMIT, formulaLimit: DAILY_FORMULA_LIMIT };
    }
    if (formulaUsed >= DAILY_FORMULA_LIMIT) {
      return { allowed: false, reason: "formula_total", dailyUsed, formulaUsed, dailyLimit: DAILY_TOTAL_LIMIT, formulaLimit: DAILY_FORMULA_LIMIT };
    }

    // 自增计数（upsert）
    await env.DB.prepare(
      "INSERT INTO report_usage (device_id, formula, report_date, count) VALUES (?, ?, ?, 1) " +
      "ON CONFLICT(device_id, formula, report_date) DO UPDATE SET count = count + 1"
    ).bind(deviceId, key, today).run();

    return { allowed: true, dailyUsed: dailyUsed + 1, formulaUsed: formulaUsed + 1, dailyLimit: DAILY_TOTAL_LIMIT, formulaLimit: DAILY_FORMULA_LIMIT };
  } catch {
    // 限流检查失败时放行（不阻塞用户），但记日志
    return { allowed: true, dailyUsed: 0, formulaUsed: 0, dailyLimit: DAILY_TOTAL_LIMIT, formulaLimit: DAILY_FORMULA_LIMIT };
  }
}
