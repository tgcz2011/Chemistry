// 化学式解析器 / Chemical formula parser
// 支持：元素符号、数字、括号 () [] {}、水合物 · / .、电荷 ^2- / +、状态 (s)(l)(g)(aq)
// Returns composition map, molar mass, normalized formula, and any error.

import { ELEMENTS, lookupElement } from "../data/elements";

export interface ParseResult {
  ok: boolean;
  error?: string;                       // 解析错误说明 / parse error description
  composition: Record<string, number>;  // 元素 → 原子数
  mass: number;                         // 摩尔质量 g/mol
  normalized: string;                   // 规范化后的化学式
  original: string;
  charge: number | null;
  state: string | null;                 // (s)(l)(g)(aq)
  hydrateParts: string[];               // 水合物各部分
  unknownElements: string[];            // 未识别元素
}

const STATE_RE = /\((s|l|g|aq)\)\s*$/i;

function extractState(input: string): { body: string; state: string | null } {
  const m = input.match(STATE_RE);
  if (m) return { body: input.slice(0, m.index).trim(), state: m[1].toLowerCase() };
  return { body: input.trim(), state: null };
}

function parseChargeStr(s: string): number {
  const sign = s.endsWith("+") ? 1 : -1;
  const numStr = s.replace(/[+-]/g, "");
  const n = numStr === "" ? 1 : parseInt(numStr, 10);
  return sign * n;
}

// Extract trailing charge: ^2-, ^+, 2-, 3+, +
function extractCharge(body: string): { core: string; charge: number | null } {
  let core = body;

  // Caret form first: e.g. SO4^2-
  const caret = core.match(/\^([0-9]*[+-])$/);
  if (caret) {
    return { core: core.slice(0, caret.index).trim(), charge: parseChargeStr(caret[1]) };
  }

  // Trailing + or - with optional number, but only when preceded by ] ) } or lowercase letter
  // (so we don't eat the count of an element like the "2" in "O2")
  const tail = core.match(/([\]\)\}a-z])(\d*[+-])$/);
  if (tail) {
    const charge = parseChargeStr(tail[2]);
    return { core: (core.slice(0, tail.index! + 1)).trim(), charge };
  }

  return { core, charge: null };
}

function dedup(arr: string[]): string[] {
  return Array.from(new Set(arr));
}

function snapshotOf(comp: Record<string, number>): Record<string, number> {
  const out: Record<string, number> = {};
  for (const k in comp) out[k] = comp[k];
  return out;
}

// Parse a single segment (no leading coefficient). Bracket counts handled via snapshot diff.
function parsePart(
  segment: string,
  composition: Record<string, number>,
  coef: number,
  unknown: string[]
): string | null {
  let i = 0;
  const n = segment.length;

  const mulStack: number[] = [coef];
  const snapStack: Record<string, number>[] = [snapshotOf(composition)];

  const consumeCount = (): number => {
    let numStr = "";
    while (i < n && /[0-9]/.test(segment[i])) {
      numStr += segment[i];
      i++;
    }
    return numStr === "" ? 1 : parseInt(numStr, 10);
  };

  const curMul = (): number => mulStack.reduce((a, b) => a * b, 1);

  while (i < n) {
    const ch = segment[i];

    if (ch === "(" || ch === "[" || ch === "{") {
      i++;
      mulStack.push(1);
      snapStack.push(snapshotOf(composition));
      continue;
    }
    if (ch === ")" || ch === "]" || ch === "}") {
      i++;
      const cnt = consumeCount();
      const start = snapStack.pop()!;
      mulStack.pop();
      if (cnt !== 1) {
        for (const sym of Object.keys(composition)) {
          const before = start[sym] || 0;
          const now = composition[sym] || 0;
          const diff = now - before;
          if (diff !== 0) composition[sym] = before + diff * cnt;
        }
      }
      continue;
    }

    if (/[A-Z]/.test(ch)) {
      let sym = ch;
      i++;
      if (i < n && /[a-z]/.test(segment[i])) {
        sym += segment[i];
        i++;
      }
      const cnt = consumeCount();
      const el = lookupElement(sym);
      if (!el) {
        unknown.push(sym);
        continue;
      }
      composition[el.symbol] = (composition[el.symbol] || 0) + curMul() * cnt;
      continue;
    }

    if (/[0-9]/.test(ch)) {
      // stray number (e.g. leading coefficient left over); consume
      consumeCount();
      continue;
    }

    return `无法识别的字符 '${ch}' / unrecognized character '${ch}'`;
  }

  return null;
}

export function parseFormula(input: string): ParseResult {
  const original = input;
  const empty: ParseResult = {
    ok: false,
    composition: {},
    mass: 0,
    normalized: "",
    original,
    charge: null,
    state: null,
    hydrateParts: [],
    unknownElements: [],
  };

  if (!input || !input.trim()) {
    return { ...empty, error: "请输入化学式 / please enter a formula" };
  }

  const { body, state } = extractState(input);
  const { core, charge } = extractCharge(body);

  // Split hydrate parts on '·', '•', '*', or '.' (when '.' is a hydrate separator before a digit)
  const sep = core.replace(/[·•*]/g, "§").replace(/([A-Za-z\)\]\}0-9])\s*\.\s*(?=[0-9])/g, "$1§");
  const parts: string[] = [];
  for (const p of sep.split("§")) {
    const t = p.trim();
    if (t) parts.push(t);
  }

  if (parts.length === 0) return { ...empty, error: "空化学式 / empty formula" };

  const composition: Record<string, number> = {};
  const unknown: string[] = [];
  let firstErr: string | null = null;

  for (const part of parts) {
    let seg = part;
    let coef = 1;
    const m = seg.match(/^(\d+)\s*(.*)$/);
    if (m) {
      coef = parseInt(m[1], 10);
      seg = m[2];
    }
    const err = parsePart(seg, composition, coef, unknown);
    if (err && !firstErr) firstErr = err;
  }

  const normalized = parts.join("·");

  let mass = 0;
  for (const [sym, cnt] of Object.entries(composition)) {
    const el = ELEMENTS[sym];
    if (el) mass += el.mass * cnt;
  }

  if (firstErr) {
    return {
      ...empty,
      ok: false,
      error: firstErr,
      composition,
      mass,
      normalized,
      charge,
      state,
      hydrateParts: parts,
      unknownElements: dedup(unknown),
    };
  }

  if (Object.keys(composition).length === 0) {
    return { ...empty, error: "未识别到任何元素 / no elements recognized" };
  }

  return {
    ok: true,
    composition,
    mass,
    normalized,
    original,
    charge,
    state,
    hydrateParts: parts,
    unknownElements: dedup(unknown),
  };
}
