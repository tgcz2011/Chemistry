// 内联前端 UI / Inline frontend UI
// Aesthetic: editorial lab-notebook — cream/ink palette, serif display + sans body,
// asymmetric layout, grid-paper texture, sulfur-yellow accent.

import { allKnownFormulas } from "./data/compounds";

export function renderHTML(): string {
  const formulas = allKnownFormulas();
  const datalist = formulas
    .map((f) => `<option value="${escapeHtml(f)}">`)
    .join("");

  return `<!DOCTYPE html>
<html lang="zh-CN" data-theme="dark" data-lang="cn">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>化学式速查 · Formula Atlas</title>
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,700;9..144,900&family=IBM+Plex+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet" />
<style>
  :root {
    --serif: "Fraunces", "Songti SC", Georgia, serif;
    --sans: "IBM Plex Sans", -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif;
    --mono: "JetBrains Mono", "SF Mono", Menlo, monospace;

    --ink: #1a1714;
    --paper: #f4ede0;
    --paper-2: #ebe2d0;
    --rule: #c9bda3;
    --accent: #d4a017;        /* sulfur yellow */
    --accent-2: #8b1e1e;      /* bromine red */
    --muted: #6b6253;
    --info: #2d5a3d;
    --warn: #b8651a;
    --danger: #8b1e1e;
    --card: #fbf6ea;
  }
  [data-theme="dark"] {
    --ink: #f0e8d6;
    --paper: #14110d;
    --paper-2: #1d1813;
    --rule: #3a3128;
    --accent: #e8b923;
    --accent-2: #e07474;
    --muted: #9a8f7a;
    --info: #7fc99a;
    --warn: #e8a45c;
    --danger: #e07474;
    --card: #1a1610;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body { background: var(--paper); color: var(--ink); font-family: var(--sans); min-height: 100vh; -webkit-font-smoothing: antialiased; }

  body {
    background-image:
      linear-gradient(var(--rule) 1px, transparent 1px),
      linear-gradient(90deg, var(--rule) 1px, transparent 1px);
    background-size: 28px 28px;
    background-position: -1px -1px;
    background-color: var(--paper);
    opacity: 1;
  }
  body::before {
    content: "";
    position: fixed; inset: 0;
    background:
      radial-gradient(1200px 600px at 80% -10%, color-mix(in srgb, var(--accent) 8%, transparent), transparent 60%),
      radial-gradient(900px 500px at -10% 110%, color-mix(in srgb, var(--accent-2) 7%, transparent), transparent 60%);
    pointer-events: none; z-index: 0;
  }

  .wrap { position: relative; z-index: 1; max-width: 1180px; margin: 0 auto; padding: 32px 28px 80px; }

  /* ---- Masthead ---- */
  header.masthead {
    display: flex; align-items: flex-end; justify-content: space-between;
    border-bottom: 2px solid var(--ink); padding-bottom: 14px; margin-bottom: 8px;
    gap: 16px; flex-wrap: wrap;
  }
  .brand { display: flex; align-items: baseline; gap: 14px; }
  .brand .mark {
    font-family: var(--serif); font-weight: 900; font-size: 44px; line-height: 0.9;
    letter-spacing: -0.02em; font-style: italic;
  }
  .brand .mark .dot { color: var(--accent); }
  .brand .sub {
    font-family: var(--serif); font-style: italic; font-size: 14px; color: var(--muted);
    border-left: 1px solid var(--rule); padding-left: 14px;
  }
  .controls { display: flex; gap: 8px; align-items: center; }
  .toggle {
    font-family: var(--sans); font-size: 12px; letter-spacing: 0.08em; text-transform: uppercase;
    background: transparent; color: var(--ink); border: 1px solid var(--ink);
    padding: 7px 12px; cursor: pointer; transition: all 0.18s ease;
  }
  .toggle:hover { background: var(--ink); color: var(--paper); }
  .toggle .seg { display: inline-flex; }
  .toggle .seg span { padding: 0 4px; opacity: 0.4; }
  .toggle .seg span.on { opacity: 1; font-weight: 600; }

  .issue {
    font-family: var(--mono); font-size: 11px; color: var(--muted); letter-spacing: 0.1em;
    text-transform: uppercase; margin-top: 4px;
  }

  /* ---- Hero / Input ---- */
  section.hero { margin-top: 28px; display: grid; grid-template-columns: 1fr 320px; gap: 36px; align-items: start; }
  @media (max-width: 880px) { section.hero { grid-template-columns: 1fr; gap: 24px; } }

  .lead { font-family: var(--serif); font-weight: 400; font-size: 22px; line-height: 1.45; color: var(--ink); margin-bottom: 22px; max-width: 38ch; }
  .lead em { color: var(--accent-2); font-style: italic; }
  .lead .small { display: block; font-family: var(--sans); font-size: 13px; color: var(--muted); margin-top: 8px; font-style: normal; }

  .field {
    display: flex; align-items: stretch; border: 2px solid var(--ink); background: var(--card);
    box-shadow: 6px 6px 0 var(--ink); transition: box-shadow 0.18s ease, transform 0.18s ease;
  }
  .field:focus-within { box-shadow: 3px 3px 0 var(--accent-2); transform: translate(-1px, -1px); }
  .field .prefix {
    font-family: var(--serif); font-style: italic; font-weight: 700; font-size: 22px;
    padding: 14px 16px; border-right: 1px solid var(--rule); color: var(--muted);
    display: flex; align-items: center;
  }
  .field input {
    flex: 1; border: none; outline: none; background: transparent; color: var(--ink);
    font-family: var(--mono); font-size: 22px; font-weight: 500; padding: 14px 12px;
    letter-spacing: 0.02em; min-width: 0;
  }
  .field input::placeholder { color: var(--muted); font-family: var(--serif); font-style: italic; font-size: 18px; }
  .field button {
    border: none; border-left: 1px solid var(--rule); background: var(--ink); color: var(--paper);
    font-family: var(--sans); font-weight: 600; font-size: 13px; letter-spacing: 0.12em; text-transform: uppercase;
    padding: 0 22px; cursor: pointer; transition: background 0.18s ease;
  }
  .field button:hover { background: var(--accent-2); }

  .chips { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 14px; }
  .chip {
    font-family: var(--mono); font-size: 12px; padding: 5px 10px; cursor: pointer;
    background: transparent; color: var(--ink); border: 1px solid var(--rule); transition: all 0.15s ease;
  }
  .chip:hover { border-color: var(--ink); background: var(--paper-2); }
  .chip .lbl { font-family: var(--sans); color: var(--muted); margin-left: 6px; font-size: 11px; }

  /* sidebar */
  aside.sidebar { border-left: 1px solid var(--rule); padding-left: 24px; }
  @media (max-width: 880px) { aside.sidebar { border-left: none; padding-left: 0; border-top: 1px solid var(--rule); padding-top: 20px; } }
  aside.sidebar h3 { font-family: var(--serif); font-style: italic; font-size: 18px; font-weight: 500; margin-bottom: 12px; }
  aside.sidebar p { font-size: 13px; color: var(--muted); line-height: 1.6; margin-bottom: 14px; }
  .kbd-list { display: flex; flex-direction: column; gap: 8px; }
  .kbd-list li { list-style: none; font-size: 12px; color: var(--muted); display: flex; gap: 10px; align-items: baseline; }
  .kbd-list code { font-family: var(--mono); background: var(--paper-2); padding: 1px 6px; border: 1px solid var(--rule); font-size: 11px; color: var(--ink); }

  /* 最近搜索 / recent searches */
  .recent-list { display: flex; flex-direction: column; gap: 4px; max-height: 220px; overflow-y: auto; }
  .recent-list .item {
    display: flex; align-items: center; justify-content: space-between; gap: 8px;
    font-family: var(--mono); font-size: 12px; padding: 5px 8px; cursor: pointer;
    background: transparent; color: var(--ink); border: 1px solid transparent; transition: all 0.15s ease;
    text-align: left;
  }
  .recent-list .item:hover { border-color: var(--rule); background: var(--paper-2); }
  .recent-list .item .f { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .recent-list .item .x {
    font-family: var(--sans); font-size: 11px; color: var(--muted); padding: 0 4px;
    border: none; background: transparent; cursor: pointer; line-height: 1; opacity: 0.5;
  }
  .recent-list .item .x:hover { opacity: 1; color: var(--accent-2); }
  .recent-list .empty-hint { font-size: 12px; color: var(--muted); font-style: italic; font-family: var(--serif); }
  .recent-list .clear {
    font-family: var(--sans); font-size: 10px; letter-spacing: 0.08em; text-transform: uppercase;
    color: var(--muted); background: transparent; border: none; cursor: pointer; padding: 4px 0;
    text-align: left; margin-top: 4px;
  }
  .recent-list .clear:hover { color: var(--accent-2); }

  /* ---- Result ---- */
  section.result { margin-top: 40px; }
  .result-card {
    background: var(--card); border: 1px solid var(--rule); padding: 0;
    animation: rise 0.4s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  @keyframes rise { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }

  .result-head {
    display: grid; grid-template-columns: auto 1fr auto; gap: 18px; align-items: center;
    padding: 20px 24px; border-bottom: 1px solid var(--rule);
  }
  .badge {
    font-family: var(--mono); font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase;
    padding: 6px 10px; border: 1px solid currentColor; font-weight: 600;
  }
  .badge.exists { color: var(--info); }
  .badge.likely { color: var(--info); }
  .badge.questionable { color: var(--warn); }
  .badge.unlikely { color: var(--danger); }
  .badge.invalid { color: var(--danger); }

  .result-head .title { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
  .result-head .formula {
    font-family: var(--mono); font-size: 30px; font-weight: 700; letter-spacing: 0.01em;
    overflow-wrap: anywhere;
  }
  .result-head .name { font-family: var(--serif); font-style: italic; color: var(--muted); font-size: 15px; }
  .result-head .mass {
    font-family: var(--serif); font-size: 13px; color: var(--muted); text-align: right;
    text-transform: uppercase; letter-spacing: 0.08em;
  }
  .result-head .mass b { display: block; font-family: var(--mono); font-style: normal; font-size: 22px; color: var(--ink); font-weight: 600; letter-spacing: 0; }

  .result-body { display: grid; grid-template-columns: 1fr 1fr; }
  @media (max-width: 760px) { .result-body { grid-template-columns: 1fr; } }

  .panel { padding: 20px 24px; }
  .panel + .panel { border-left: 1px solid var(--rule); }
  @media (max-width: 760px) { .panel + .panel { border-left: none; border-top: 1px solid var(--rule); } }
  .panel h4 {
    font-family: var(--serif); font-style: italic; font-weight: 500; font-size: 13px;
    text-transform: uppercase; letter-spacing: 0.1em; color: var(--muted); margin-bottom: 14px;
  }

  /* element table */
  table.el { width: 100%; border-collapse: collapse; font-size: 13px; }
  table.el th, table.el td { text-align: left; padding: 7px 6px; border-bottom: 1px dashed var(--rule); }
  table.el th { font-family: var(--sans); font-weight: 500; font-size: 11px; text-transform: uppercase; letter-spacing: 0.08em; color: var(--muted); }
  table.el td.sym { font-family: var(--mono); font-weight: 600; font-size: 14px; }
  table.el td.bar { width: 38%; }
  .bar-track { height: 6px; background: var(--paper-2); position: relative; }
  .bar-fill { position: absolute; left: 0; top: 0; bottom: 0; background: var(--accent); }

  /* notes */
  ul.notes { list-style: none; display: flex; flex-direction: column; gap: 12px; }
  li.note {
    border-left: 3px solid var(--rule); padding: 6px 0 6px 14px; font-size: 14px; line-height: 1.6;
  }
  li.note.info { border-color: var(--info); }
  li.note.warn { border-color: var(--warn); }
  li.note.danger { border-color: var(--danger); }
  li.note .lvl {
    display: inline-block; font-family: var(--mono); font-size: 10px; letter-spacing: 0.1em;
    text-transform: uppercase; padding: 2px 6px; margin-right: 8px; border: 1px solid currentColor; vertical-align: middle;
  }
  li.note.info .lvl { color: var(--info); }
  li.note.warn .lvl { color: var(--warn); }
  li.note.danger .lvl { color: var(--danger); }

  /* 颜色区块 / color swatches */
  .colors-row { display: flex; flex-wrap: wrap; gap: 8px; }
  .color-chip {
    display: inline-flex; align-items: center; gap: 7px;
    font-family: var(--mono); font-size: 12px; padding: 5px 9px;
    border: 1px solid var(--rule); background: var(--paper-2);
  }
  .color-chip .sw {
    width: 14px; height: 14px; border: 1px solid var(--ink); display: inline-block; flex-shrink: 0;
    background-image: linear-gradient(45deg, var(--muted) 25%, transparent 25%, transparent 75%, var(--muted) 75%);
    background-size: 6px 6px;
  }
  .color-chip .ctx { color: var(--muted); font-family: var(--sans); font-size: 11px; }
  .color-chip .nm { color: var(--ink); }

  .empty { padding: 60px 24px; text-align: center; color: var(--muted); font-family: var(--serif); font-style: italic; font-size: 18px; }

  /* action bar */
  .result-actions {
    display: flex; align-items: center; justify-content: space-between; gap: 12px;
    padding: 11px 24px; border-top: 1px solid var(--rule); background: var(--paper-2);
    flex-wrap: wrap;
  }
  .cache-tag {
    font-family: var(--mono); font-size: 10px; letter-spacing: 0.08em; text-transform: uppercase;
    color: var(--muted); display: inline-flex; align-items: center; gap: 6px;
  }
  .cache-tag .dot { width: 6px; height: 6px; border-radius: 50%; background: var(--accent); display: inline-block; }
  .report-btn {
    font-family: var(--sans); font-size: 11px; letter-spacing: 0.08em; text-transform: uppercase;
    background: transparent; color: var(--accent-2); border: 1px solid var(--accent-2);
    padding: 6px 12px; cursor: pointer; transition: all 0.18s ease; font-weight: 600;
    display: inline-flex; align-items: center; gap: 6px;
  }
  .report-btn:hover:not(:disabled) { background: var(--accent-2); color: var(--paper); }
  .report-btn:disabled { opacity: 0.5; cursor: wait; }

  /* re-analyzing overlay */
  .overlay {
    position: fixed; inset: 0; background: color-mix(in srgb, var(--paper) 86%, transparent);
    display: flex; align-items: center; justify-content: center; z-index: 100;
    animation: rise 0.2s ease;
  }
  .overlay .box {
    background: var(--card); border: 2px solid var(--ink); box-shadow: 6px 6px 0 var(--ink);
    padding: 34px 42px; text-align: center; max-width: 440px;
  }
  .overlay .box .icon { font-family: var(--serif); font-size: 34px; color: var(--accent-2); margin-bottom: 6px; }
  .overlay .box .ttl { font-family: var(--serif); font-style: italic; font-size: 22px; font-weight: 700; margin-bottom: 10px; }
  .overlay .box .desc { font-size: 14px; color: var(--muted); line-height: 1.6; margin-bottom: 16px; }
  .overlay .box .warn-line { font-family: var(--mono); font-size: 11px; letter-spacing: 0.08em; text-transform: uppercase; color: var(--accent-2); display: inline-flex; align-items: center; gap: 8px; }
  .toast {
    position: fixed; bottom: 26px; left: 50%; transform: translateX(-50%);
    background: var(--ink); color: var(--paper); font-family: var(--sans); font-size: 13px;
    padding: 10px 18px; box-shadow: 3px 3px 0 var(--accent-2); z-index: 200;
    animation: rise 0.2s ease; max-width: 90vw; text-align: center;
  }
  .toast.err { box-shadow: 3px 3px 0 var(--danger); }

  /* footer */
  footer { margin-top: 60px; padding-top: 18px; border-top: 1px solid var(--rule); display: flex; justify-content: space-between; font-family: var(--mono); font-size: 11px; color: var(--muted); letter-spacing: 0.08em; text-transform: uppercase; flex-wrap: wrap; gap: 10px; }

  .spin { display: inline-block; width: 12px; height: 12px; border: 2px solid var(--muted); border-top-color: var(--ink); border-radius: 50%; animation: sp 0.8s linear infinite; vertical-align: middle; }
  @keyframes sp { to { transform: rotate(360deg); } }

  /* ---- 移动端优化 ---- */
  @media (max-width: 640px) {
    .wrap { padding: 18px 14px 60px; }

    /* Masthead: 缩小品牌字，控件紧凑 */
    header.masthead { padding-bottom: 10px; gap: 10px; }
    .brand { gap: 10px; }
    .brand .mark { font-size: 30px; }
    .brand .sub { font-size: 12px; padding-left: 10px; }
    .controls { gap: 6px; }
    .toggle { padding: 6px 9px; font-size: 11px; }
    .issue { font-size: 10px; }

    /* Hero 间距收紧 */
    section.hero { margin-top: 18px; gap: 18px; }
    .lead { font-size: 17px; margin-bottom: 16px; }
    .lead .small { font-size: 12px; margin-top: 6px; }

    /* 搜索框：减小偏移阴影/字号/padding，按钮收窄 */
    .field { box-shadow: 4px 4px 0 var(--ink); }
    .field:focus-within { box-shadow: 2px 2px 0 var(--accent-2); transform: translate(-1px, -1px); }
    .field .prefix { font-size: 18px; padding: 12px 12px; }
    .field input { font-size: 18px; padding: 12px 10px; }
    .field input::placeholder { font-size: 15px; }
    .field button { padding: 0 14px; font-size: 12px; letter-spacing: 0.08em; }

    .chips { gap: 5px; margin-top: 12px; }
    .chip { font-size: 11px; padding: 4px 8px; }
    .chip .lbl { font-size: 10px; margin-left: 4px; }

    /* sidebar */
    aside.sidebar { padding-top: 16px; }
    aside.sidebar h3 { font-size: 16px; margin-bottom: 10px; }
    aside.sidebar p { font-size: 12px; }

    /* 结果卡：头部三列改两行，字号收小，padding 收紧 */
    section.result { margin-top: 28px; }
    .result-head {
      grid-template-columns: 1fr; gap: 10px; padding: 16px 16px;
    }
    .result-head .title { gap: 2px; }
    .result-head .formula { font-size: 24px; }
    .result-head .name { font-size: 14px; }
    .result-head .mass { text-align: left; }
    .result-head .mass b { font-size: 18px; display: inline-block; margin-left: 6px; }

    .panel { padding: 16px; }
    .panel h4 { font-size: 12px; margin-bottom: 12px; }

    /* 元素表：紧凑，防溢出 */
    table.el { font-size: 12px; }
    table.el th, table.el td { padding: 6px 4px; }
    table.el td.sym { font-size: 13px; }
    table.el td.bar { width: 34%; }

    /* 注意事项：紧凑 */
    ul.notes { gap: 10px; }
    li.note { font-size: 13px; padding: 5px 0 5px 12px; line-height: 1.55; }
    li.note .lvl { font-size: 9px; padding: 1px 5px; margin-right: 6px; }

    /* 操作栏：紧凑 */
    .result-actions { padding: 10px 16px; gap: 8px; }
    .cache-tag { font-size: 9px; }
    .report-btn { font-size: 10px; padding: 5px 10px; }

    /* overlay：缩小，留边距 */
    .overlay .box { padding: 24px 22px; max-width: calc(100vw - 32px); box-shadow: 4px 4px 0 var(--ink); }
    .overlay .box .icon { font-size: 28px; }
    .overlay .box .ttl { font-size: 18px; }
    .overlay .box .desc { font-size: 13px; }

    /* toast：上移避开 home indicator */
    .toast { bottom: 20px; left: 16px; right: 16px; transform: none; max-width: none; font-size: 12px; padding: 9px 14px; }

    /* footer */
    footer { margin-top: 40px; padding-top: 14px; font-size: 10px; gap: 8px; }
  }

  [hidden] { display: none !important; }

  /* lang visibility */
  [data-lang="cn"] .en-only { display: none; }
  [data-lang="en"] .cn-only { display: none; }
</style>
</head>
<body>
  <div class="wrap">
    <header class="masthead">
      <div>
        <div class="brand">
          <div class="mark">Formula<span class="dot">·</span>Atlas</div>
          <div class="sub"><span class="cn-only">化学式速查图鉴</span><span class="en-only">A field guide to chemical substances</span></div>
        </div>
        <div class="issue"><span class="cn-only">第 壹 卷 · 本地 250+ 条目 · 联网 1.1 亿+</span><span class="en-only">Vol. I · 250+ local · 110M+ online</span></div>
      </div>
      <div class="controls">
        <button class="toggle" id="langToggle" aria-label="language">
          <span class="seg"><span class="on" data-l="cn">中</span><span data-l="en">EN</span></span>
        </button>
        <button class="toggle" id="themeToggle" aria-label="theme">
          <span class="cn-only">夜</span><span class="en-only">Night</span> / <span class="cn-only">昼</span><span class="en-only">Day</span>
        </button>
      </div>
    </header>

    <section class="hero">
      <div>
        <p class="lead">
          <span class="cn-only">输入任意<em>化学式</em>，瞬时判断其是否存在、是否稳定，并附实验室级别的注意事项。</span>
          <span class="en-only">Type any <em>formula</em> to instantly see whether the substance exists, how stable it is, and the lab-grade precautions you should know.</span>
          <span class="small"><span class="cn-only">本地数据库收录 250+ 化合物；未命中时自动联网查询 PubChem（1.1 亿+ 化合物）。支持括号、水合物、电荷与状态符号，例如 CuSO₄·5H₂O、SO₄^2-、NaCl(s)</span><span class="en-only">Local DB has 250+ compounds; falls back to PubChem online (110M+ compounds) when not found. Supports parentheses, hydrates, charges and state symbols — e.g. CuSO₄·5H₂O, SO₄^2-, NaCl(s)</span></span>
        </p>

        <form id="form" autocomplete="off">
          <div class="field">
            <span class="prefix">ƒ</span>
            <input id="formula" name="formula" list="known" placeholder="H2SO4 · AgOH · CuSO4·5H2O ..." spellcheck="false" autocapitalize="off" />
            <datalist id="known">${datalist}</datalist>
            <button type="submit"><span class="cn-only">解析</span><span class="en-only">Analyze</span></button>
          </div>
        </form>

        <div class="chips" id="chips"></div>
      </div>

      <aside class="sidebar">
        <h3><span class="cn-only">体例</span><span class="en-only">Notation</span></h3>
        <p>
          <span class="cn-only">元素首字母大写、次字母小写（Na、Cl、Fe）。括号 ()[]{} 可嵌套，水合物用 · 或 . 分隔，电荷用 ^2- / ^+ 或尾随 + / -。</span>
          <span class="en-only">Capitalize element symbols (Na, Cl, Fe). Nest brackets ()[]{}, separate hydrates with · or ., write charges as ^2- / ^+ or trailing + / -.</span>
        </p>
        <ul class="kbd-list">
          <li><code>Enter</code> <span class="cn-only">提交当前化学式</span><span class="en-only">Submit the formula</span></li>
          <li><code>↑ ↓</code> <span class="cn-only">浏览历史记录</span><span class="en-only">Browse history</span></li>
          <li><code>AgOH</code> <span class="cn-only">试试这个不稳定例子</span><span class="en-only">Try this unstable example</span></li>
        </ul>
        <h3 style="margin-top:22px"><span class="cn-only">最近搜索</span><span class="en-only">Recent</span></h3>
        <div id="recent" class="recent-list"></div>
      </aside>
    </section>

    <section class="result" id="result" hidden>
      <div class="result-card" id="card"></div>
    </section>

    <div class="empty" id="empty" hidden></div>

    <footer>
      <span><span class="cn-only">由 Cloudflare Workers 驱动</span><span class="en-only">Powered by Cloudflare Workers</span></span>
      <span>Formula·Atlas — <span class="cn-only">化学式速查图鉴</span><span class="en-only">A field guide</span></span>
    </footer>
  </div>

<script>
  const LANG = {
    cn: {
      analyzing: "分析中…", emptyTitle: "尚无结果", emptyHint: "在上方输入一个化学式，按解析按钮（或回车）。",
      colElement: "元素", colCount: "原子数", colMass: "质量分数", composition: "元素组成", notes: "注意事项",
      massLabel: "摩尔质量", unit: "g/mol", category: "类别", notInDb: "未在数据库",
      back: "返回",
      srcLocal: "本地数据库", srcCache: "缓存", srcOnline: "联网",
      reportBtn: "上报信息有误", reportLocal: "本地条目 · 暂不支持上报",
      reTitle: "正在重新分析", reDesc: "AI 正在重新搜索 PubChem 与维基百科，并总结最新注意事项…",
      doNotClose: "请勿关闭网页", reDone: "已重新分析并更新", reFail: "重新分析失败",
      colors: "颜色",
      examples: [
        ["H2SO4","硫酸"],["AgOH","氢氧化银"],["CuSO4·5H2O","五水硫酸铜"],["NaCl","氯化钠"],
        ["O3","臭氧"],["Fe2O3","氧化铁"],["KMnO4","高锰酸钾"],["NaOH","氢氧化钠"],
        ["Cl2O7","七氧化二氯"],["H2O2","过氧化氢"],["NH3","氨气"],["CaC2","碳化钙"]
      ]
    },
    en: {
      analyzing: "Analyzing…", emptyTitle: "No results yet", emptyHint: "Type a formula above and press Analyze (or Enter).",
      colElement: "Element", colCount: "Atoms", colMass: "Mass %", composition: "Composition", notes: "Precautions",
      massLabel: "Molar mass", unit: "g/mol", category: "Category", notInDb: "Not in DB",
      back: "Back",
      srcLocal: "Local DB", srcCache: "Cache", srcOnline: "Online",
      reportBtn: "Report inaccuracy", reportLocal: "Local entry · reporting unavailable",
      reTitle: "Re-analyzing", reDesc: "AI is re-searching PubChem & Wikipedia and summarizing fresh precautions…",
      doNotClose: "Do not close this page", reDone: "Re-analyzed and updated", reFail: "Re-analysis failed",
      colors: "Color",
      examples: [
        ["H2SO4","Sulfuric acid"],["AgOH","Silver hydroxide"],["CuSO4·5H2O","Copper(II) sulfate pentahydrate"],["NaCl","Sodium chloride"],
        ["O3","Ozone"],["Fe2O3","Iron(III) oxide"],["KMnO4","Potassium permanganate"],["NaOH","Sodium hydroxide"],
        ["Cl2O7","Dichlorine heptoxide"],["H2O2","Hydrogen peroxide"],["NH3","Ammonia"],["CaC2","Calcium carbide"]
      ]
    }
  };

  const root = document.documentElement;
  const $ = (s) => document.querySelector(s);
  const form = $("#form"), input = $("#formula"), cardEl = $("#card"), resultEl = $("#result"), emptyEl = $("#empty");

  // ---- localStorage 持久化 / Persistence ----
  const STORE = {
    lang: "fa_lang",      // "cn" | "en"
    theme: "fa_theme",    // "dark" | "light"
    hist: "fa_hist",      // string[] (最近 50 条)
  };
  function lsGet(k, dflt) {
    try { const v = localStorage.getItem(k); return v == null ? dflt : v; } catch { return dflt; }
  }
  function lsGetJSON(k, dflt) {
    try { const v = localStorage.getItem(k); return v == null ? dflt : JSON.parse(v); } catch { return dflt; }
  }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch {} }
  function lsSetJSON(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }

  let curLang = lsGet(STORE.lang, "cn") === "en" ? "en" : "cn";

  function t() { return LANG[curLang]; }

  function setLang(l) {
    curLang = l;
    lsSet(STORE.lang, l);
    root.setAttribute("data-lang", l);
    document.querySelectorAll("#langToggle .seg span").forEach(s => s.classList.toggle("on", s.dataset.l === l));
    renderChips();
    renderRecent();
    if (lastResult) render(lastResult); else showEmpty();
  }
  function setTheme(th) {
    lsSet(STORE.theme, th);
    root.setAttribute("data-theme", th);
    const btn = $("#themeToggle");
    btn.querySelector(".cn-only").textContent = th === "dark" ? "夜" : "昼";
    btn.querySelector(".en-only").textContent = th === "dark" ? "Night" : "Day";
  }

  $("#langToggle").addEventListener("click", () => setLang(curLang === "cn" ? "en" : "cn"));
  $("#themeToggle").addEventListener("click", () => setTheme(root.getAttribute("data-theme") === "dark" ? "light" : "dark"));

  // history (从 localStorage 恢复 / restore from localStorage)
  const hist = lsGetJSON(STORE.hist, []);
  let histIdx = -1;
  input.addEventListener("keydown", (e) => {
    if (e.key === "ArrowUp") { if (hist.length) { histIdx = Math.min(histIdx + 1, hist.length - 1); input.value = hist[hist.length - 1 - histIdx] || ""; } e.preventDefault(); }
    else if (e.key === "ArrowDown") { histIdx = Math.max(histIdx - 1, -1); input.value = histIdx === -1 ? "" : hist[hist.length - 1 - histIdx]; e.preventDefault(); }
    else if (e.key === "Enter") { e.preventDefault(); submit(input.value); }
  });

  form.addEventListener("submit", (e) => { e.preventDefault(); submit(input.value); });

  function submit(v) {
    v = (v || "").trim();
    if (!v) return;
    // 去重并追加到末尾（最近搜索在前）
    const idx = hist.indexOf(v);
    if (idx >= 0) hist.splice(idx, 1);
    hist.push(v);
    if (hist.length > 50) hist.shift();
    lsSetJSON(STORE.hist, hist);
    histIdx = -1;
    renderRecent();
    analyze(v);
  }

  // 渲染最近搜索列表（倒序：最近在前）
  function renderRecent() {
    const el = $("#recent");
    if (!el) return;
    if (hist.length === 0) {
      el.innerHTML = '<div class="empty-hint">' + escapeHtml(curLang === "cn" ? "暂无记录" : "No history yet") + '</div>';
      return;
    }
    const items = hist.slice().reverse().slice(0, 12).map((f, i) => {
      const realIdx = hist.length - 1 - i;
      return '<div class="item" data-i="' + realIdx + '">' +
        '<span class="f">' + escapeHtml(f) + '</span>' +
        '<button class="x" data-del="' + realIdx + '" title="' + escapeHtml(curLang === "cn" ? "删除" : "Remove") + '">×</button>' +
      '</div>';
    }).join("");
    el.innerHTML = items +
      '<button class="clear" id="clearHist">' + escapeHtml(curLang === "cn" ? "清空全部" : "Clear all") + '</button>';

    el.querySelectorAll(".item").forEach(it => {
      it.addEventListener("click", (e) => {
        if (e.target instanceof HTMLElement && e.target.classList.contains("x")) return;
        const i = Number(it.getAttribute("data-i"));
        const f = hist[i];
        if (f) { input.value = f; submit(f); }
      });
    });
    el.querySelectorAll(".x").forEach(b => {
      b.addEventListener("click", (e) => {
        e.stopPropagation();
        const i = Number(b.getAttribute("data-del"));
        if (!Number.isNaN(i)) { hist.splice(i, 1); lsSetJSON(STORE.hist, hist); renderRecent(); }
      });
    });
    const clr = $("#clearHist");
    if (clr) clr.addEventListener("click", () => {
      hist.length = 0; lsSetJSON(STORE.hist, hist); renderRecent();
    });
  }

  function renderChips() {
    const el = $("#chips"); el.innerHTML = "";
    for (const [f, label] of t().examples) {
      const b = document.createElement("button");
      b.type = "button"; b.className = "chip";
      b.innerHTML = escapeHtml(f) + '<span class="lbl">' + escapeHtml(label) + '</span>';
      b.addEventListener("click", () => { input.value = f; submit(f); });
      el.appendChild(b);
    }
  }

  let lastResult = null;
  async function analyze(v) {
    resultEl.hidden = false; emptyEl.hidden = true;
    cardEl.innerHTML = '<div style="padding:40px;text-align:center;font-family:var(--serif);font-style:italic;color:var(--muted);font-size:18px"><span class="spin"></span> ' + escapeHtml(t().analyzing) + '</div>';
    try {
      const r = await fetch("/api/analyze?formula=" + encodeURIComponent(v));
      const j = await r.json();
      lastResult = j;
      render(j);
    } catch (err) {
      cardEl.innerHTML = '<div style="padding:30px;color:var(--danger)">⚠ ' + escapeHtml(String(err)) + '</div>';
    }
  }

  function showEmpty() {
    resultEl.hidden = true; emptyEl.hidden = false;
    emptyEl.innerHTML = '<span>' + escapeHtml(t().emptyTitle) + '</span><br><span style="font-size:13px;font-style:normal">' + escapeHtml(t().emptyHint) + '</span>';
  }

  function render(j) {
    const L = curLang;
    const name = j.nameCn || j.nameEn || (L === "cn" ? "（未在数据库）" : "(Not in database)");
    const nameDisplay = L === "cn" ? (j.nameCn || j.nameEn || name) : (j.nameEn || j.nameCn || name);
    const existenceTxt = L === "cn" ? j.existenceCn : j.existenceEn;
    const cat = L === "cn" ? (j.categoryCn || t().notInDb) : (j.categoryEn || t().notInDb);

    const elements = (j.elements || []).map(e => {
      const elName = L === "cn" ? e.name_cn : e.name_en;
      const pct = (e.massPct || 0);
      return '<tr><td class="sym">' + escapeHtml(e.symbol) + '</td><td>' + escapeHtml(elName) + '</td><td>' + e.count + '</td><td class="bar"><div class="bar-track"><div class="bar-fill" style="width:' + pct.toFixed(1) + '%"></div></div></td><td style="text-align:right;font-family:var(--mono)">' + pct.toFixed(2) + '%</td></tr>';
    }).join("");

    const notes = (j.notes || []).map(n => {
      const lvl = n.level || "info";
      const lbl = lvl === "warn" ? "⚠" : lvl === "danger" ? "✕" : "i";
      const txt = L === "cn" ? n.cn : n.en;
      return '<li class="note ' + lvl + '"><span class="lvl">' + lbl + '</span>' + escapeHtml(txt) + '</li>';
    }).join("");

    // 颜色区块：按形态分类显示色块（仅生成内部内容，外层 panel 由调用处包裹）
    const colorsInner = (j.colors && j.colors.length)
      ? '<h4>' + escapeHtml(t().colors) + '</h4><div class="colors-row">' +
          j.colors.map(c => {
            const ctxTxt = L === "cn" ? c.ctx_cn : (c.ctx_en || c.ctx_cn);
            const nmTxt = L === "cn" ? c.cn : (c.en || c.cn);
            const swStyle = c.hex ? ('background-color:' + escapeHtml(c.hex)) : '';
            return '<div class="color-chip">' +
              '<span class="sw"' + (swStyle ? ' style="' + swStyle + '"' : '') + '></span>' +
              '<span class="ctx">' + escapeHtml(ctxTxt) + '</span>' +
              '<span class="nm">' + escapeHtml(nmTxt) + '</span>' +
            '</div>';
          }).join('') +
        '</div>'
      : '';

    const mass = (j.mass || 0).toFixed(3);

    // source tag + report button
    const isLocal = !!j.found && !!j.compound;
    const fromCache = !!j.fromCache;
    const srcLabel = isLocal ? t().srcLocal : (fromCache ? t().srcCache : t().srcOnline);
    const canReport = !isLocal;

    const actionsBar =
      '<div class="result-actions">' +
        '<span class="cache-tag"><span class="dot"></span>' + escapeHtml(srcLabel) + '</span>' +
        (canReport
          ? '<button class="report-btn" id="reportBtn" type="button">⚑ ' + escapeHtml(t().reportBtn) + '</button>'
          : '<span style="font-family:var(--mono);font-size:10px;color:var(--muted);letter-spacing:0.08em;text-transform:uppercase">' + escapeHtml(t().reportLocal) + '</span>') +
      '</div>';

    cardEl.innerHTML = '' +
      '<div class="result-head">' +
        '<span class="badge ' + j.existence + '">' + escapeHtml(existenceTxt) + '</span>' +
        '<div class="title">' +
          '<div class="formula">' + escapeHtml(j.input) + (j.parse && j.parse.normalized && j.parse.normalized !== j.input ? ' <span style="color:var(--muted);font-size:14px;font-family:var(--serif);font-style:italic">→ ' + escapeHtml(j.parse.normalized) + '</span>' : '') + '</div>' +
          '<div class="name">' + escapeHtml(nameDisplay) + (cat ? ' · ' + escapeHtml(cat) : '') + '</div>' +
        '</div>' +
        '<div class="mass">' + escapeHtml(t().massLabel) + '<b>' + mass + ' <span style="font-size:11px;color:var(--muted)">' + escapeHtml(t().unit) + '</span></b></div>' +
      '</div>' +
      '<div class="result-body">' +
        '<div class="panel"><h4>' + escapeHtml(t().composition) + '</h4>' +
          (elements ? '<table class="el"><thead><tr><th>' + escapeHtml(t().colElement) + '</th><th></th><th>' + escapeHtml(t().colCount) + '</th><th>' + escapeHtml(t().colMass) + '</th><th></th></tr></thead><tbody>' + elements + '</tbody></table>'
                    : '<div style="color:var(--muted);font-style:italic">—</div>') +
        '</div>' +
        '<div class="panel"><h4>' + escapeHtml(t().notes) + '</h4>' +
          (notes ? '<ul class="notes">' + notes + '</ul>' : '<div style="color:var(--muted);font-style:italic">—</div>') +
        '</div>' +
        (colorsInner ? '<div class="panel" style="grid-column:1/-1;border-top:1px solid var(--rule);border-left:none">' + colorsInner + '</div>' : '') +
      '</div>' +
      actionsBar;

    // bind report button
    const rb = document.getElementById("reportBtn");
    if (rb) rb.addEventListener("click", () => reportInaccuracy(j.input));
  }

  // ---- 上报信息有误：强制 AI 重新搜索总结（带限流） ----
  // 持久设备 ID：localStorage 生成，防清除；后端另有 IP+UA 哈希兜底
  function getDeviceId() {
    try {
      let did = localStorage.getItem("fa_did");
      if (!did) {
        did = "u-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
        localStorage.setItem("fa_did", did);
      }
      return did;
    } catch { return ""; }
  }

  function reportInaccuracy(formula) {
    const L = curLang;
    // 覆盖层：提醒用户不要关闭网页
    const ov = document.createElement("div");
    ov.className = "overlay";
    ov.id = "reOverlay";
    ov.innerHTML =
      '<div class="box">' +
        '<div class="icon"><span class="spin" style="width:20px;height:20px;border-width:3px"></span></div>' +
        '<div class="ttl">' + escapeHtml(L === "cn" ? "正在重新分析" : "Re-analyzing") + '</div>' +
        '<div class="desc">' + escapeHtml(L === "cn" ? "AI 正在重新搜索 PubChem 与维基百科，并总结最新注意事项…" : "AI is re-searching PubChem & Wikipedia and summarizing fresh precautions…") + '</div>' +
        '<div class="warn-line">⚠ ' + escapeHtml(L === "cn" ? "请勿关闭网页" : "Do not close this page") + '</div>' +
      '</div>';
    document.body.appendChild(ov);

    const did = getDeviceId();
    fetch("/api/report?formula=" + encodeURIComponent(formula) + (did ? "&did=" + encodeURIComponent(did) : ""))
      .then(r => r.json().then(j => ({ status: r.status, j })))
      .then(({ status, j }) => {
        ov.remove();
        if (j.ok && j.result) {
          lastResult = j.result;
          render(j.result);
          // 附带剩余次数提示
          let extra = "";
          if (j.limit) {
            extra = L === "cn"
              ? "（今日已用 " + j.limit.dailyUsed + "/" + j.limit.dailyLimit + "，本式 " + j.limit.formulaUsed + "/" + j.limit.formulaLimit + "）"
              : " (today " + j.limit.dailyUsed + "/" + j.limit.dailyLimit + ", this formula " + j.limit.formulaUsed + "/" + j.limit.formulaLimit + ")";
          }
          toast((L === "cn" ? "已重新分析并更新" : "Re-analyzed and updated") + extra, false);
        } else if (j.limited) {
          // 限流：显示具体原因
          toast((j.error || (L === "en" ? j.errorEn : "")) || (L === "cn" ? "上报次数已达上限" : "Report limit reached"), true);
        } else {
          toast((L === "cn" ? "重新分析失败" : "Re-analysis failed") + (j.error ? "：" + j.error : ""), true);
        }
      })
      .catch(err => {
        ov.remove();
        toast((L === "cn" ? "重新分析失败" : "Re-analysis failed") + "：" + escapeHtml(String(err)), true);
      });
  }

  function toast(msg, isErr) {
    const el = document.createElement("div");
    el.className = "toast" + (isErr ? " err" : "");
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => { el.style.transition = "opacity 0.3s"; el.style.opacity = "0"; }, 2600);
    setTimeout(() => el.remove(), 3000);
  }

  function escapeHtml(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function(c) {
      return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c];
    });
  }

  // init — 从 localStorage 恢复偏好，无记录时回退到系统/默认
  const storedTheme = lsGet(STORE.theme, "");
  const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
  setTheme(storedTheme === "light" || storedTheme === "dark" ? storedTheme : (prefersDark ? "dark" : "light"));
  setLang(curLang);  // setLang 内部会调用 renderChips + renderRecent
  showEmpty();

  // autofocus
  input.focus();
</script>
</body>
</html>`;
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c] as string));
}
