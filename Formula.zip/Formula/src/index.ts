// Cloudflare Worker 入口 / Worker entry
// 路由:
//   GET  /            -> 内联 HTML UI
//   GET  /api/analyze -> JSON 分析结果 (本地DB -> D1缓存 -> 联网PubChem+Wiki+AI -> 回写D1)
//   GET  /api/report  -> 用户上报信息有误：强制 AI 重新搜索总结并更新缓存
//   GET  /api/health  -> 健康检查

import { analyzeFormula, type AnalysisResult, type AnalysisNote } from "./lib/analyzer";
import { searchByFormula, getSynonyms } from "./lib/pubchem";
import { searchWikiByName, searchWiki, type WikiResult } from "./lib/wiki";
import { aiJudgeFormula, type AiNote } from "./lib/ai";
import { getCached, setCached, checkAndIncrReport } from "./lib/db";
import { renderHTML } from "./ui";

interface Env {
  AI: any;
  DB: any;
}

const HTML_CACHE: { html: string } | null = null;

function getHTML(): string {
  return HTML_CACHE?.html ?? renderHTML();
}

// 设备指纹兜底：无前端 did 时，用 IP + UA 生成稳定哈希
function getDeviceId(request: Request): string {
  const cf = (request as any).cf as any;
  const ip = request.headers.get("CF-Connecting-IP") || request.headers.get("X-Forwarded-For") || "unknown";
  const ua = request.headers.get("User-Agent") || "unknown";
  // 简单 djb2 哈希，生成 16 进制字符串
  const src = ip + "|" + ua;
  let h = 5381;
  for (let i = 0; i < src.length; i++) h = ((h << 5) + h + src.charCodeAt(i)) >>> 0;
  return "ip-" + h.toString(16);
}

// 是否需要对某分析结果做联网兜底
function shouldFallbackToPubChem(r: AnalysisResult): boolean {
  if (r.found) return false;
  if (r.existence === "invalid") return false;
  if (r.existence === "unlikely") return false;
  return r.parse?.ok === true;
}

// 从 AnalysisResult 的 notes 里提取 PubChem 命中信息（缓存刷新时复用，避免重查 PubChem）
interface PubchemFact {
  name?: string;
  cid?: number;
  isomers?: number;
  hit: boolean;
}

function extractPubchemFact(r: AnalysisResult): PubchemFact {
  for (const n of r.notes) {
    const m = n.cn.match(/PubChem（CID\s*(\d+)/);
    if (m) {
      return { cid: Number(m[1]), hit: true };
    }
  }
  // 若存在性是"存在（联网证实）"但没解析出 CID，也视为命中
  if (r.existence === "exists" && r.found) return { hit: true };
  return { hit: false };
}

// 用 AI 重新生成注意事项（基于已有事实 + Wikipedia），替换旧 AI 备注
function replaceAiNotes(notes: AnalysisNote[], newAiNotes: AiNote[]): AnalysisNote[] {
  const kept = notes.filter((n) => !n.cn.includes("AI 推断"));
  return [...kept, ...newAiNotes];
}

// 从分析备注里提取技术性提示（酸根、价态等），作为事实传给 AI
function extractLocalHints(notes: AnalysisNote[]): string[] {
  const hints: string[] = [];
  for (const n of notes) {
    // 含"酸根""价态校验"等技术性关键词的备注
    if (/酸根|价态校验|结构/.test(n.cn)) {
      hints.push(n.cn.replace(/[。，].*$/, "").trim());
    }
  }
  return hints;
}

// 判断一个"中文名"候选是否可信
// 过滤掉 WikiData 误命中的论文标题、英文句子、全大写串等
function trustworthyNameCn(s: string | undefined): string | undefined {
  if (!s) return undefined;
  const t = s.trim();
  if (!t) return undefined;
  // 含 4 个以上连续空格分隔的英文单词 → 论文/句子，丢弃
  if (/^[A-Z0-9 \-:,().]+$/i.test(t) && (t.match(/\s/g)?.length ?? 0) >= 3) return undefined;
  // 全大写英文（如 "GOETHITE"）→ 单词可作英文，但不作中文名
  if (/^[A-Z\s]+$/.test(t)) return undefined;
  // 过长且以英文为主（>30 字符且中文字符 < 2 个）
  const cnCount = (t.match(/[\u4e00-\u9fff]/g) || []).length;
  if (t.length > 30 && cnCount < 2) return undefined;
  // "A STUDY ON..." 类论文标题
  if (/^a\s+(study|review|note|new)\s/i.test(t)) return undefined;
  return t;
}

// 从 wiki.zh 取可信中文名（WikiData label 需过滤）
function wikiNameCn(wiki: WikiResult | null): string | undefined {
  if (!wiki?.zh) return undefined;
  // Wikipedia 中文标题可信度较高；WikiData 需过滤
  if (wiki.zh.source === "wikipedia") return wiki.zh.title;
  return trustworthyNameCn(wiki.zh.title);
}

// 联网增强：PubChem + Wikipedia 取事实 + AI 总结注意事项
async function enrichOnline(r: AnalysisResult, env: Env, opts: { refresh?: AnalysisResult | null } = {}): Promise<AnalysisResult> {
  const refresh = opts.refresh;
  const pub = await searchByFormula(r.input);

  // 去掉本地分析里残留的元信息备注，只保留价态/酸根等有用技术备注
  const notes: AnalysisNote[] = r.notes.filter(
    (n) => !n.cn.includes("不在内置数据库") && !n.cn.includes("已联网查询")
  );

  // PubChem 未命中
  if (!pub.ok || pub.hits.length === 0) {
    // Wikipedia 辅助搜索（用化学式搜）
    let wiki: WikiResult | null = null;
    try { wiki = await searchWiki(r.input); } catch { /* ignore */ }

    const ai = await aiJudgeFormula(env, {
      formula: r.input,
      composition: r.composition,
      mass: r.mass,
      pubchem: null,
      wiki,
      localHints: extractLocalHints(notes),
      refresh: refresh ? { oldNotes: refresh.notes.filter((n) => n.cn.includes("AI 推断")) as AiNote[] } : null,
      charge: r.parse?.charge ?? null,
    });

    if (ai.ok) {
      if (ai.notes.length) notes.push(...ai.notes);
      return {
        ...r,
        notes,
        existence: ai.existence,
        existenceCn: ai.existence === "likely" ? "可能存在（AI 推断）" : ai.existence === "unlikely" ? "极可能不存在（AI 推断）" : "存疑（AI 推断）",
        existenceEn: ai.existence === "likely" ? "Likely (AI inferred)" : ai.existence === "unlikely" ? "Most likely not (AI inferred)" : "Questionable (AI inferred)",
        nameCn: trustworthyNameCn(ai.nameCn) || r.nameCn || wikiNameCn(wiki),
        nameEn: r.nameEn || ai.nameEn || wiki?.en?.title,
        colors: ai.colors ?? r.colors,
      };
    }
    notes.push({ level: "warn", cn: ai.errorCn ?? "联网查询未果", en: ai.errorEn ?? "Online lookup yielded no result" });
    return { ...r, notes, existence: r.existence === "likely" ? "questionable" : r.existence };
  }

  // PubChem 命中
  const top = pub.hits[0];
  const pubNames: string[] = [];
  if (top.iupacName) pubNames.push(top.iupacName);
  if (top.title && top.title !== top.iupacName) pubNames.push(top.title);

  let synonymCn = "";
  try {
    const syns = await getSynonyms(top.cid);
    const cn = syns.find((s) => /[\u4e00-\u9fff]/.test(s));
    if (cn) synonymCn = cn;
    if (syns.length) {
      const extra = syns.filter((s) => !pubNames.includes(s) && s.length < 60).slice(0, 2);
      pubNames.push(...extra);
    }
  } catch { /* ignore */ }

  const pubNameDisplay = pubNames.slice(0, 3).join(" / ");

  // Wikipedia 用英文名搜（效果更好）
  let wiki: WikiResult | null = null;
  try { wiki = await searchWikiByName(pubNameDisplay.split(" / ")[0] || r.input, r.input); } catch { /* ignore */ }

  const ai = await aiJudgeFormula(env, {
    formula: r.input,
    composition: r.composition,
    mass: r.mass,
    pubchem: { name: pubNameDisplay, cid: top.cid, isomers: pub.hits.length },
    wiki,
    localHints: extractLocalHints(notes),
    refresh: refresh ? { oldNotes: refresh.notes.filter((n) => n.cn.includes("AI 推断")) as AiNote[] } : null,
    charge: r.parse?.charge ?? null,
  });

  if (ai.ok && ai.notes.length) notes.push(...ai.notes);

  // PubChem + Wikipedia 详情链接（有用，保留）
  const sourceNotes: AnalysisNote[] = [{
    level: "info",
    cn: `数据来源：PubChem（CID ${top.cid}，规范化式 ${top.molecularFormula}，分子量 ${top.molecularWeight}）。详情：https://pubchem.ncbi.nlm.nih.gov/compound/${top.cid}`,
    en: `Source: PubChem (CID ${top.cid}, formula ${top.molecularFormula}, MW ${top.molecularWeight}). Details: https://pubchem.ncbi.nlm.nih.gov/compound/${top.cid}`,
  }];
  if (wiki?.zh?.url) {
    const zhLabel = wiki.zh.source === "wikidata" ? "维基数据" : "维基百科（中文）";
    const zhLabelEn = wiki.zh.source === "wikidata" ? "Wikidata" : "Wikipedia (zh)";
    sourceNotes.push({ level: "info", cn: `${zhLabel}：${wiki.zh.url}`, en: `${zhLabelEn}: ${wiki.zh.url}` });
  }
  if (wiki?.en?.url) {
    const enLabel = wiki.en.source === "wikidata" ? "维基数据（英文）" : "维基百科（英文）";
    const enLabelEn = wiki.en.source === "wikidata" ? "Wikidata" : "Wikipedia (en)";
    sourceNotes.push({ level: "info", cn: `${enLabel}：${wiki.en.url}`, en: `${enLabelEn}: ${wiki.en.url}` });
  }

  notes.push(...sourceNotes);

  return {
    ...r,
    found: true,
    existence: "exists",
    existenceCn: "存在（联网证实）",
    existenceEn: "Exists (confirmed online)",
    nameCn: trustworthyNameCn(ai.nameCn) || synonymCn || wikiNameCn(wiki) || r.nameCn || pubNameDisplay,
    nameEn: pubNameDisplay || ai.nameEn || wiki?.en?.title || r.nameEn,
    categoryCn: r.categoryCn ?? "联网查询",
    categoryEn: r.categoryEn ?? "Online lookup",
    mass: r.mass || top.molecularWeight,
    notes,
    colors: ai.ok ? (ai.colors ?? r.colors) : r.colors,
  };
}

// 缓存刷新：基于旧缓存结果，重新跑 AI（PubChem 信息复用，不重查），补充/修正注意事项
async function refreshCached(env: Env, cached: AnalysisResult): Promise<AnalysisResult> {
  const fact = extractPubchemFact(cached);

  // 复用旧缓存的 PubChem 名称信息（若有）
  let pubchemHint: { name?: string; cid?: number; isomers?: number } | null = null;
  if (fact.hit) {
    pubchemHint = { name: cached.nameEn, cid: fact.cid };
  }

  // Wikipedia 重新搜（事实可能更新）
  let wiki: WikiResult | null = null;
  try {
    wiki = pubchemHint?.name
      ? await searchWikiByName(pubchemHint.name, cached.input)
      : await searchWiki(cached.input);
  } catch { /* ignore */ }

  const ai = await aiJudgeFormula(env, {
    formula: cached.input,
    composition: cached.composition,
    mass: cached.mass,
    pubchem: pubchemHint,
    wiki,
    localHints: extractLocalHints(cached.notes),
    refresh: { oldNotes: cached.notes.filter((n) => n.cn.includes("AI 推断")) as AiNote[] },
    charge: cached.parse?.charge ?? null,
  });

  // 用新 AI 注意事项替换旧 AI 注意事项，保留来源链接等非 AI 备注
  const newNotes = replaceAiNotes(cached.notes, ai.ok ? ai.notes : []);

  let result: AnalysisResult = {
    ...cached,
    notes: newNotes,
    fromCache: false,
  };

  if (ai.ok) {
    result = {
      ...result,
      existence: cached.existence === "exists" ? "exists" : ai.existence, // 已联网证实的存在性不降级
      existenceCn: cached.existence === "exists" ? cached.existenceCn : (
        ai.existence === "likely" ? "可能存在（AI 推断）" : ai.existence === "unlikely" ? "极可能不存在（AI 推断）" : "存疑（AI 推断）"
      ),
      existenceEn: cached.existence === "exists" ? cached.existenceEn : (
        ai.existence === "likely" ? "Likely (AI inferred)" : ai.existence === "unlikely" ? "Most likely not (AI inferred)" : "Questionable (AI inferred)"
      ),
      nameCn: trustworthyNameCn(ai.nameCn) || cached.nameCn || wikiNameCn(wiki),
      nameEn: ai.nameEn || cached.nameEn || wiki?.en?.title,
      colors: ai.colors ?? cached.colors,
    };
  }

  return result;
}

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    // ---- 上报：信息有误，强制 AI 重新搜索总结（带限流） ----
    if (path === "/api/report") {
      const formula = url.searchParams.get("formula") ?? "";
      const deviceId = (url.searchParams.get("did") ?? "").trim();

      try {
        let result = analyzeFormula(formula);
        if (!shouldFallbackToPubChem(result)) {
          // 本地 DB 命中的，无法上报刷新
          return new Response(JSON.stringify({ ok: false, error: "本地数据库条目不支持上报刷新" }), {
            status: 200, headers: { "Content-Type": "application/json; charset=utf-8", ...corsHeaders },
          });
        }

        // 限流：设备 ID 优先，无设备 ID 用 IP 兜底
        const did = deviceId || getDeviceId(request);
        const limit = await checkAndIncrReport(env, did, formula);
        if (!limit.allowed) {
          const msg = limit.reason === "daily_total"
            ? `今日上报次数已达上限（${limit.dailyLimit} 次），请明日再试`
            : `该化学式今日上报次数已达上限（${limit.formulaLimit} 次），请明日再试`;
          const msgEn = limit.reason === "daily_total"
            ? `Daily report limit reached (${limit.dailyLimit}/day). Please try tomorrow.`
            : `Per-formula report limit reached (${limit.formulaLimit}/day). Please try tomorrow.`;
          return new Response(JSON.stringify({ ok: false, error: msg, errorEn: msgEn, limited: true, limit }), {
            status: 429, headers: { "Content-Type": "application/json; charset=utf-8", "Retry-After": "86400", ...corsHeaders },
          });
        }

        // 通过限流，忽略缓存完整重跑联网（PubChem + Wiki + AI）
        result = await enrichOnline(result, env, { refresh: null });
        const hasAiNotes = result.notes.some((n) => n.cn.includes("AI 推断"));
        if (hasAiNotes || result.existence === "unlikely") {
          ctx.waitUntil(setCached(env, formula, result));
        }

        return new Response(JSON.stringify({ ok: true, result, limit: { dailyUsed: limit.dailyUsed, dailyLimit: limit.dailyLimit, formulaUsed: limit.formulaUsed, formulaLimit: limit.formulaLimit } }), {
          status: 200, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...corsHeaders },
        });
      } catch (err) {
        return new Response(JSON.stringify({ ok: false, error: String(err) }), {
          status: 500, headers: { "Content-Type": "application/json; charset=utf-8", ...corsHeaders },
        });
      }
    }

    // ---- API ----
    if (path === "/api/analyze") {
      const formula = url.searchParams.get("formula") ?? "";
      const online = url.searchParams.get("online") !== "0";
      try {
        let result = analyzeFormula(formula);

        if (online && shouldFallbackToPubChem(result)) {
          // 1. 先查 D1 缓存
          const cached = await getCached(env, formula);
          if (cached) {
            if (!cached.stale) {
              // 新鲜缓存，直接返回
              return new Response(JSON.stringify(cached.result), {
                status: 200,
                headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...corsHeaders },
              });
            }
            // 过期缓存（>14天）：先返回旧结果（快速响应），后台 AI 重新补充并更新
            // 为让用户尽快看到结果，先返回缓存的旧版，并在后台刷新
            ctx.waitUntil((async () => {
              try {
                const refreshed = await refreshCached(env, cached.result);
                await setCached(env, formula, refreshed);
              } catch { /* ignore */ }
            })());
            cached.result.fromCache = true;
            return new Response(JSON.stringify(cached.result), {
              status: 200,
              headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...corsHeaders },
            });
          }
          // 2. 无缓存：联网 PubChem + Wiki + AI
          result = await enrichOnline(result, env);
          // 3. 仅当结果含 AI 注意事项时才回写缓存
          const hasAiNotes = result.notes.some((n) => n.cn.includes("AI 推断"));
          if (hasAiNotes || result.existence === "unlikely") {
            ctx.waitUntil(setCached(env, formula, result));
          }
        }

        return new Response(JSON.stringify(result), {
          status: 200,
          headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...corsHeaders },
        });
      } catch (err) {
        return new Response(
          JSON.stringify({ ok: false, error: String(err), input: formula }),
          { status: 500, headers: { "Content-Type": "application/json; charset=utf-8", ...corsHeaders } }
        );
      }
    }

    if (path === "/api/health") {
      return new Response(JSON.stringify({ ok: true, t: Date.now() }), {
        headers: { "Content-Type": "application/json; charset=utf-8", ...corsHeaders },
      });
    }

    // ---- UI ----
    if (path === "/" || path === "/index.html") {
      const html = getHTML();
      return new Response(html, {
        status: 200,
        headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "public, max-age=300", ...corsHeaders },
      });
    }

    return new Response("Not found", {
      status: 404,
      headers: { "Content-Type": "text/plain; charset=utf-8", ...corsHeaders },
    });
  },
};
